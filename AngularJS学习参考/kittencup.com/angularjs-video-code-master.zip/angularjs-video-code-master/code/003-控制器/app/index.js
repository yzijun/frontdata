

var firstController = function($scope){

    // $scope 我们叫做作用域
    // 申明一个Model
    $scope.name = '张三';

    $scope.age = 20;

}