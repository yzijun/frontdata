

var firstController = function($scope){


    $scope.name = '张三';
    console.log($scope);

}

var secondController = function($scope){

    console.log($scope);
}