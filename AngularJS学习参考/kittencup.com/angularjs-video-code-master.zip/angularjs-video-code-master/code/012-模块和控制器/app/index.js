

var myApp = angular.module('myApp',[]);


myApp.controller('firstController',function($scope){
    $scope.name = '张三';
});


