<template>
  <div class="page" :transition="transitionName">	
  <div class="container">	
	  <div class="inner-scroll">
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>	
		<h1>{{ msg }}</h1>	
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>	
		<h1>{{ msg }}</h1>	
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>
		<h1>{{ msg }}</h1>	
		<h1>{{ msg }}</h1>	
		<h1>{{ msg }}</h1>		
	  </div>
  </div>
  </div>
</template>

<script>

export default {	
  data () {
    return {
	  msg: 'Hello Vue',
      transitionName: null
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1 {
  color: #42b983;
}
</style>
