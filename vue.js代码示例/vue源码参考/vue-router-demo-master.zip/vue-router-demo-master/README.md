#本教程适合刚学Vue.js 且想自己搭建路由的同学。如果这个demo 对你有帮助请点击 “star” 一下。谢谢
#Vue router
环境

node v6.2.0
cnpm 4.3.2
npm 3.8.9
Vue 1.0.12 版本

通过npm安装本地服务第三方依赖模块(需要已安装Node.js)，使用npm安装依赖模块可能会很慢，建议换成cnpm
npm install -g cnpm --registry=http://registry.npm.taobao.org

# 安装依赖模块
cnpm install

# 启动服务
npm run dev

# 发布代码
npm run build

#发布代码后的服务
npm run main