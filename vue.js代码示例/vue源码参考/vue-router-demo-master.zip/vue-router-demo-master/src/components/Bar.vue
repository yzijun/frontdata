<template>
    <nav>
        <slot></slot>
    </nav>
</template>
