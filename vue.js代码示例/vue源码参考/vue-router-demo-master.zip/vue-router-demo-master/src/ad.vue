<template>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6 text-center">
                <img src="assets/img/vue.png" alt="广告">
            </div>
            <div class="col-md-3"></div>
        </div>
        <div class="row text-center">
            <a class="btn btn-primary" v-link="{path:'/m'}">进入</a>
        </div>
    </div>
</template>
<style scoped>

</style>