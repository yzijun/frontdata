/**
 * Created by qbl on 2016/8/25.
 */
export default {
    /*常量*/
    API_BASE:"http://192.168.13.111/YchLrestServer/api",

    SESSIONID:"",
}