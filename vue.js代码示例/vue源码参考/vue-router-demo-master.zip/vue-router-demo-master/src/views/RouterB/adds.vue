<template>
    <div class="jumbotron">
        <h1>adds</h1>
        <p>...</p>
        <ul class="nav nav-tabs" role="tablist">
            <li role="presentation" class="active">
                <a v-link="" role="tab" data-toggle="tab">item1</a>
            </li>
            <li role="presentation">
                <a v-link="" role="tab" data-toggle="tab">item2</a>
            </li>
        </ul>
    </div>
</template>