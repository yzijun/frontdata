<template>
    <div class="jumbotron">
        <h1>lists</h1>
        <p>...</p>
        <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a></p>
    </div>
</template>