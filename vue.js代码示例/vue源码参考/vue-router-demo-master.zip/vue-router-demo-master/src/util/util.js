import $ from 'jquery'
/*通用方法*/