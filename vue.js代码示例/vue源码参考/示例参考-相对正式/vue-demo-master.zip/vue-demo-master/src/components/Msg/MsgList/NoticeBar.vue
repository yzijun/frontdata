<template>
  <div
    role="alert"
    class="alert alert-warning alert-dismissible">
    <button
      type="button"
      class="close"
      data-dismiss="alert">
      <span aria-hidden="true">&times;</span>
    </button>
    <strong>暂无更多信息</strong>
  </div>
</template>
