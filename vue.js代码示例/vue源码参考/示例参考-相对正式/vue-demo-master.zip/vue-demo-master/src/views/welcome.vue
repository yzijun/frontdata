<template>

  <div class="jumbotron">
    <h1>欢迎使用 Vue Demo</h1>
    <p>
      <a
        role="button"
        class="btn btn-success btn-lg"
        v-link="'/msg'">
        前往留言板 &gt;
      </a>
    </p>
  </div>
  
</template>
