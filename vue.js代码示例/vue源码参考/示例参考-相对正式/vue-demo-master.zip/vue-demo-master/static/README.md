放置高度静态但不经由 Webpack 处理的文件
e.g. jQuery 等
