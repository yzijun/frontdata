<template>
  <p class="not">404, 页面没有发现.</p>
</template>
<script>
export default {
}
</script>
<style>
.not{
  text-align: center;
  font-size: 36px;
  margin-top: 20%;
}
</style>