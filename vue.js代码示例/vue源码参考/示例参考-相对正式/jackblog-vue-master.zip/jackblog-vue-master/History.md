### [查看Releases](https://github.com/jackhutu/jackblog-vue/releases)

1.2.3 / 2016-07-11
==================

* 更新依赖及相关代码
* 增加styleModel cookie存储

1.2.2 / 2016-05-07
==================

* 修复消息提示组件
* 更新依赖包


1.2.1 / 2016-04-08
==================

* 更新vue 到 1.0.21
* 更新vue-router 到 0.7.13
* 更新vue-validator 到 2.0.1
* 更新jackblog-sass 到 1.0.4
* 增加eslint代码检查


1.2.0 / 2016-03-15
==================

* 更新vue 到 1.0.17
* 更新vuex 到 0.6.2
* 更新jackblog-sass 到 1.0.3
* 重新设计消息提示组件

1.1.1 / 2016-02-28
==================

* fix #1 webpack config没有设置publicPath项.

1.1.0 / 2016-02-28
==================

* 去掉sass文件, 全用独立css npm 安装包 =>  jackblog-sass
* 同时去掉node-sass, sass-loader等相关库
* 增加scroll to top 组件


1.0.0 / 2016-02-28
==================

* 完成基本功能
* vuex + vue-router + vue-resource