/**
 * 用函数规定返回的errMsg数据类型
 */
export const setMsg = (state, msg) => {
  return {
    success: state,
    msg: msg
  }
}
