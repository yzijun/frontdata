// content
export const SET_CONTENT = 'SET_CONTENT'
export const REFRESH_CONTENT = 'REFRESH_CONTENT'

// doc
export const SET_DOC_MENU = 'SET_DOC_MENU'
export const SET_TIP = 'SET_TIP'
export const SET_LOADING = 'SET_LOADING'

// user info
export const SET_BASEINFO = 'SET_BASEINFO'
export const SET_DETAIL = 'SET_DETAIL'
export const DELETE_USER_INFO = 'DELETE_USER_INFO'
export const SET_MSGS = 'SET_MSGS'
