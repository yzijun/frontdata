# vue-cnode

> 一个vue单页应用demo

## 安装

clone

``` bash
git clone https://github.com/wszgxa/vue-cnode
```

安装modules

``` bash
npm install
```

开发环境运行

``` bash 
npm run dev
```

获取生产线文件

``` bash 
npm run dist
```

## 展示

![](http://7fvhwe.com1.z0.glb.clouddn.com/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202016-09-17%20%E4%B8%8B%E5%8D%889.39.05.png)
![](http://7fvhwe.com1.z0.glb.clouddn.com/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202016-09-17%20%E4%B8%8B%E5%8D%889.38.06.png)
