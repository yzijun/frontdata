<template>
	<ul>
		<li>News 01</li>
		<li>News 02</li>
		<li>News 03</li>
	</ul>
</template>