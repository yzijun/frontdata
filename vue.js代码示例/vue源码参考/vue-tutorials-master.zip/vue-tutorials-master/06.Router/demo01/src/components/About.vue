<template>
	<div>
		<h1>About</h1>
		<p>This is the tutorial about vue-router.</p>
	</div>
</template>

<script>
	export default{
		
	}
</script>