<template>
	<div>
		News Detail - {{$route.params.id}} ......
	</div>
</template>