
var index = Vue.extend({
    template: '<p>This is foo!</p>'
})

var search = Vue.extend({
    template: '<p>This is bar!</p>'
})
var yongchi = Vue.extend({
    template: '<p>This is foo!</p>'
})

var myself = Vue.extend({
    template: '<p>This is bar!</p>'
})


var App = Vue.extend({
	
})
var router = new VueRouter()
router.map({
    '/index': {
        component: index
    },
    '/search': {
        component: search
    },
    '/yongchi': {
        component: yongchi
    },
    '/myself': {
        component: myself
    }
})
router.start(App, '#app')


