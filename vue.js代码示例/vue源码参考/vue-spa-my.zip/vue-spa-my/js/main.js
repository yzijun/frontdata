var data=[{
	icon:'&#xe65a;',
	name:'首页',
	luyou:'/index'
},{
	icon:'&#xe602;',
	name:'搜索',
	luyou:'/search'
},{
	icon:'&#xe61d;',
	name:'泳池',
	luyou:'/yongchi'
},{
	icon:'&#xe606;',
	name:'我的',
	luyou:'/myself'
}]


var footTemp=function(){
	var html='';

	for (var i=0;i<data.length;i++) {
		html+='<foot_children  name='+data[i].name+' icon='+data[i].icon+ ' luyou='+data[i].luyou+ '></foot_children>';
	}
	
	return '<div class="foot_bar">'+html+'</div>';
}

var a6='/index';
var abc='v-link="{ path: '+a6+' }"';
var footChildrenTemp='<a    >'
					+'<i class="iconfont">{{icon}}</i>'
					+'<span class="tab-label">{{name}}</span>'
					+'</a>';

var footer = Vue.extend({
	
 	  template: footTemp()
});
Vue.component('indexfooter', footer);

var footer_children = Vue.extend({
	  props: ['name','icon','luyou'],
  template: footChildrenTemp
})
Vue.component('foot_children', footer_children);



new Vue({
  el: '#app',
  data: {
    message: '你好!',
    data
  }
})
