var weather = '下雨';
switch (weather) {
case '下雨':
    alert('忧郁');
    break;
case '晴天':
    alert('心情不错');
    break;
default:
    alert('心情糟糕');
    break;
}