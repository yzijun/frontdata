var alertMessage = function (message) {
    alert(message);
}

alertMessage('hola');