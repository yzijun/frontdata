var beyond = {
    formedIn: '1983',
    foundedIn: '香港',
    artist: ['黄家驹', '黄家强', '黄贯中', '叶世荣']
};

console.log(beyond);