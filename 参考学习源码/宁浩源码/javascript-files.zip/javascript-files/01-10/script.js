function alertMessage (message) {
    alert(message);
}

alertMessage('hola');