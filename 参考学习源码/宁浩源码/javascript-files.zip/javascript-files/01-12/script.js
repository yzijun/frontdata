var message = 'Hello';
var alertMessage = function () {
    // alert(message);
    var message_1 = '您好';
}
alert(message_1);
// alertMessage();