// 在控制台上输出 0 - 9 
for (var i = 0; i < 10; i++) {
    console.log(i);
}

// 在控制台上输出 week 这个数组里的所有的项目
var week = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期天'];
for (var i = 0; i < week.length; i++) {
    console.log(week[i]);
}