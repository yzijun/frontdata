var beyond = {formedIn: '1983', foundedIn: '香港'};
// beyond.formedIn = '1983';
// beyond['foundedIn'] = '香港'
console.log(beyond);