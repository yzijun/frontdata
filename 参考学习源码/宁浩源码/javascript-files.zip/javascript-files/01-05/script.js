var weather = '下雨', temperature = 26;
if ((weather === '晴天') && (temperature <= 26)) {
    alert('心情不错');
} else if (weather === '下雨') {
    alert('忧郁');
} else {
    alert('心情糟糕');
}