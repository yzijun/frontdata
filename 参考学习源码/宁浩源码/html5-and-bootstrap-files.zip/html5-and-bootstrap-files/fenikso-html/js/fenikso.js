jQuery(function($){
  $('#main-content [rel=tooltip]').tooltip()
  $('#main-content [rel=popover]').popover()
});