$(function() {

	$('#d1').click(function(){

			$(this).animateCSS('pulse', function(){

					$("#d6").addClass("circle").animateCSS('slideOutRightLong',function(){

							$(this).removeClass("circle");

							$('#d3').show().animateCSS('fadeOutUp',function(){
										$(this).hide();

										if (!$('#d4').is(":visible")) {
											$('#d4').show();
										}
										if ($('#d5').is(":visible")) {
											$('#d5').hide();
										}
										if ($('#d7').is(":visible")) {
											$('#d7').hide();
										}
										$('#d4').animateCSS('slideOutUp',function(){
											$('#d4').hide();
											$('#d5').text("1").animateCSS('slideInUp');
										});
							});
				});

			});
	});


	$('#d2').click(function(){

		$('#d9').animateCSS('fadeOutUp', function(){
			$(this).hide();
		});
		$('#d10').animateCSS('fadeOutUp',  {delay: 300,
		  callback: function(){
		    $(this).hide();
		  }
		});
		$('#d11').animateCSS('fadeOutUp',  {delay: 400,
		  callback: function(){
		    $(this).hide();
		  }
		});
		$('#d12').animateCSS('fadeOutUp',  {delay: 500,
		  callback: function(){
						$(this).hide();
						$("#d8").addClass("circle").animateCSS('slideOutRightLong',function(){

								$(this).removeClass("circle");

								$('#d3').show().animateCSS('fadeOutUp',function(){
											$(this).hide();

											if ($('#d4').is(":visible")) {
												$('#d4').hide();
											}
											if (!$('#d5').is(":visible")) {
												$('#d5').show().text("1");
											}
											if ($('#d7').is(":visible")) {
												$('#d7').hide();
											}

											$('#d5').animateCSS('slideOutUp',function(){
												$('#d5').hide();
												$('#d7').text("2").animateCSS('slideInUp');
											});
								});
					});
		  }
		});

	});
});
