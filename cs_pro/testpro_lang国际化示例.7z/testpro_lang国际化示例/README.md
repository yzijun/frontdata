# ng14x
this is a showcase of angular1.4.x & gulp & webpack 

#How to run?
1.npm install -g gulp webpack bower

2.npm install & bower install

3.gulp serve
