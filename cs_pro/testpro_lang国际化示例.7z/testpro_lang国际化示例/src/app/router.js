var routerConfig = function($stateProvider, $urlRouterProvider, $translateProvider) {
    $stateProvider
        .state('main.home', {
            url: '/home',
            template: require('./views/home.html'),
            controller: require('./controllers/homeController'),
            controllerAs: 'home'
        })
        .state('main.about', {
            url: '/about',
            template: require('./views/about.html'),
            controller: require('./controllers/aboutController'),
            controllerAs: 'about'
        })
        .state('main.broadcast', {
            url: '/broadcast',
            template: require('./views/broadcast.html'),
            controller: require('./controllers/broadcastController'),
            controllerAs: 'broadcast'
        })
        .state('main', {
            url: '/main',
            template: require('./views/main.html')
        })
        .state('login', {
            url: '/login',
            template: require('./views/login.html'),
            controller: require('./controllers/loginController'),
            controllerAs: 'languageVm',
            resolve: {
                mainTranslatePartialLoader: ['$translate', '$translatePartialLoader', function($translate, $translatePartialLoader) {
                    $translatePartialLoader.addPart('home');
                    return $translate.refresh();
                }]
            }
        })
    $urlRouterProvider.otherwise("/login");


    // Initialize angular-translate
    $translateProvider.useLoader('$translatePartialLoader', {
        urlTemplate: 'app/i18n/{lang}/{part}.json'
    });

    $translateProvider.preferredLanguage('en');
    // $translateProvider.useStorage('translationStorageProvider');
    $translateProvider.useSanitizeValueStrategy('escaped');
    $translateProvider.addInterpolation('$translateMessageFormatInterpolation');

    //auto determine preferred lang
    // $translateProvider.determinePreferredLanguage();
    //when can not determine lang, choose en lang.
    // $translateProvider.fallbackLanguage('en');

    // tmhDynamicLocaleProvider.localeLocationPattern('i18n/angular-locale_{{locale}}.js');
    // tmhDynamicLocaleProvider.useCookieStorage();
    // tmhDynamicLocaleProvider.storageKey('NG_TRANSLATE_LANG_KEY');

};
routerConfig.$inject = ['$stateProvider', '$urlRouterProvider', '$translateProvider'];
module.exports = routerConfig;