require('./styles/style.css');//css 
var $ = require('jquery');//jquery
require('bootstrap-webpack!../../bootstrap.config.js');//bootstrap
require('./myapp');//myapp

