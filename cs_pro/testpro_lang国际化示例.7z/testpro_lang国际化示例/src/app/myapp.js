var angular = require('angular');
var uiRouter = require('angular-ui-router');
var uiBootstrap = require('angular-ui-bootstrap');
var routerConfig = require('./router');

// 多语言设置相关
// var dynamicLocale = require('angular-dynamic-locale');
var translate = require('angular-translate');
require('angular-translate-interpolation-messageformat');
require('angular-translate-loader-partial');
// require('angular-translate-storage-cookie');



// var myApp = angular.module('myApp', [uiRouter, uiBootstrap, dynamicLocale, translate]);
var myApp = angular.module('myApp', [uiRouter, uiBootstrap, translate]);

myApp.config(routerConfig);

myApp.constant('LANGUAGES', [
    'en',
    'zh-cn'
]);

// myApp.filter('findLanguageFromKey', require('./language.filter'));

// require('./angular-dynamic-locale/src/tmhDynamicLocale.js');
// require('./angular-translate/dist/angular-translate.js');
// require('./angular-translate-interpolation-messageformat/angular-translate-interpolation-messageformat.js');
// require('./angular-translate-loader-partial/angular-translate-loader-partial.js');
// require('./angular-translate-storage-cookie/angular-translate-storage-cookie.js');

module.exports = myApp;