module.exports = function findLanguageFromKeyFilter(lang) {
    return {
        'en': 'English',
        'zh-cn': '中文（简体）'
    }[lang];
}