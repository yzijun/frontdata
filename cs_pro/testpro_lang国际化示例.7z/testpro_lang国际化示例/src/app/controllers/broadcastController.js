var broadcastCtrl = function ($scope) {
  var broadcast = this;
  if (!String.prototype.supplant) {
    String.prototype.supplant = function (o) {
      return this.replace(/{([^{}]*)}/g,
        function (a, b) {
          var r = o[b];
          return typeof r === 'string' || typeof r === 'number' ? r : a;
        }
      );
    };
  }

  $(function () {
    var connection = $.hubConnection("http://localhost:8649/signalr", { useDefaultPath: false });
    var tickerProxy = connection.createHubProxy('StockTickerHub'),
      //var ticker = $.connection.stockTickerMini, // the generated client-side hub proxy
      up = '▲',
      down = '▼',
      $stockTable = $('#stockTable'),
      $stockTableBody = $stockTable.find('tbody'),
      rowTemplate = '<tr data-symbol="{symbol}"><td>{symbol}</td><td>{price}</td><td>{dayOpen}</td><td>{direction} {change}</td><td>{percentChange}</td></tr>';

    function formatStock(stock) {
      return $.extend(stock, {
        price: stock.price.toFixed(2),
        percentChange: (stock.percentChange * 100).toFixed(2) + '%',
        direction: stock.change === 0 ? '' : stock.change >= 0 ? up : down
      });
    }

    function init() {
      //ticker.server.getAllStocks().done(function (stocks) {
      tickerProxy.invoke('getAllStocks').done(function (stocks) {
        $stockTableBody.empty();
        $.each(stocks, function () {
          var stock = formatStock(this);
          $stockTableBody.append(rowTemplate.supplant(stock));
        });
      });
    }

    // Add a client-side hub method that the server will call
    tickerProxy.on('updateStockPrice', function (stock) {
      var displayStock = formatStock(stock),
        $row = $(rowTemplate.supplant(displayStock));

      $stockTableBody.find('tr[data-symbol=' + stock.symbol + ']')
        .replaceWith($row);
    });

    // Start the connection
    //$.connection.hub.start().done(init);
    connection.start().done(init);
  });


  console.log('This is Broadcast controller');
};
broadcastCtrl.$inject = ['$scope', '$http'];
module.exports = broadcastCtrl;
