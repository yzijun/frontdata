var loginCtrl = function($translate, LANGUAGES) {
    var languageVm = this;

    languageVm.changeLanguage = changeLanguage;
    languageVm.languages = LANGUAGES;

    // 改变语言的状态
    // $translate.use("zh-cn");

    function changeLanguage(languageKey) {
        $translate.use(languageKey);
        // tmhDynamicLocale.set(languageKey);
    }
};
loginCtrl.$inject = ['$translate', 'LANGUAGES'];
module.exports = loginCtrl;