var angular = require('angular');
// -----依赖模块-----
var uiRouter = require('angular-ui-router');
var uiBootstrap = require('angular-ui-bootstrap');
var ngResource = require('angular-resource');
var ngCookies = require('angular-cookies');
var ngFileUpload = require('ng-file-upload');
var loadingBar = require('angular-loading-bar');
// 加载出错，暂时不用
// var ngStorage = require('ngstorage');
var routerConfig = require('./router');

var casemgmt = angular.module('casemgmt', [uiRouter, uiBootstrap, ngResource, ngCookies, ngFileUpload, loadingBar]);

casemgmt.run(require('./run'));
casemgmt.config(routerConfig);

// constants begin
casemgmt.value('urlParams', {
    "template": "http://192.168.10.192:8080/api/services/app/:api/:method",
    "api": "api",
    "method": "method"
});
// constants end

// services begin
casemgmt.factory("mainService", require('./services/mainService.js'));

casemgmt.factory("alertService", require('./services/alert/index.service'));
casemgmt.factory("alertFilterService", require('./services/alert/moreFilters.service'));
casemgmt.factory('caseService', require('./services/case/caseService'));

casemgmt.factory("roleService", require('./services/configuration/roleService.js'));
casemgmt.factory("permissionService", require('./services/configuration/permissionService.js'));
casemgmt.factory("plantAssetService", require('./services/configuration/plantAssetService.js'));
casemgmt.factory("userService", require('./services/configuration/userService.js'));
casemgmt.factory("messageConfService", require('./services/configuration/messageConfService.js'));
casemgmt.factory("kpiConfService", require('./services/configuration/kpiConfService.js'));

casemgmt.factory("mapping", require('./services/helper/mapping.js'));
casemgmt.factory("assistant", require('./services/helper/modelAssistantService.js'));
casemgmt.factory("caseManager", require('./services/helper/caseManager.js'));
casemgmt.factory("notificationManager", require('./services/helper/notificationManager.js'));

casemgmt.factory("authExpiredInterceptor", require('./services/interceptor/auth.interceptor'));
casemgmt.factory("errorHandlerInterceptor", require('./services/interceptor/errorhandler.interceptor'));
// services end

// directive begin
// casemgmt.directive("showValidation", require('./directives/form.directive'));
// casemgmt.directive("iCheck", require('./directives/icheck.directive'));
casemgmt.directive("hasAuthority", require('./directives/authority.directive'));
// directive end

require('./angular-loading-bar/loading-bar.js'); //angular-loading-bar

module.exports = casemgmt;