
var plantAssetTabcontentOperationController = function ($scope, $rootScope, $state, plantAssetService, $stateParams, mapping) {
	console.log('plantAssetTabcontentOperationController');
	var plantAssetTabcontent = this;
	//plantAssetTabcontent.stateParams = mapping.stateParams;
	plantAssetTabcontent.currentTab = $stateParams.tab;
	console.log("plantAssetTabcontent.stateParams " + plantAssetTabcontent.currentTab);

	plantAssetTabcontent.totalItems;
	plantAssetService.obtainModelList(plantAssetTabcontent.currentTab).then(function (response) {
		plantAssetTabcontent.list = response.result.data;
		plantAssetTabcontent.totalItems = response.result.total;
	}, function (error) {

	}
	);

	plantAssetTabcontent.isListShown = true;
	plantAssetTabcontent.isDetailShown = false;
	plantAssetTabcontent.onEdit = function ($event, item) {
		console.log("onedit");
		$event.stopPropagation();
		plantAssetTabcontent.isListShown = false;
		if (plantAssetTabcontent.currentTab == mapping.stateParams.tabTag) {
			$state.go("main.configuration-plantAsset.tabcontent.operations-tag"
				, {
					"id": item.id
				});
		} else {
			$state.go("main.configuration-plantAsset.tabcontent.operations"
				, {
					"tab": plantAssetTabcontent.currentTab,
					"operation": mapping.roleOperations.editRole,
					"id": item.id
				});
		}
	}

	plantAssetTabcontent.create = function () {
		console.log("create");
		plantAssetTabcontent.isListShown = false;
		$state.go("main.configuration-plantAsset.tabcontent.operations"
			, {
				"tab": plantAssetTabcontent.currentTab,
				"operation": mapping.roleOperations.createRole,
				"id": 0
			});
	}

	plantAssetTabcontent.showDetail = function (item) {
		console.log("detail");
		plantAssetTabcontent.isDetailShown = true;
		plantAssetService.obtainModelBy(plantAssetTabcontent.currentTab, item.id).then(function (response) {
			plantAssetTabcontent.detail = response.result.data;
		}, function (error) {

		}
		);
	}

	plantAssetTabcontent.closeDetail = function (item) {
		console.log("dismiss detail");
		plantAssetTabcontent.isDetailShown = false;
	}

	$scope.$on("showList", function (d, data) {
		plantAssetTabcontent.isListShown = true;
	});

	// search
	if (plantAssetTabcontent.currentTab != mapping.stateParams.tabSite) {
		plantAssetService.getSites().then(
			function (response) {
				plantAssetTabcontent.filterSites = response.result.data;
			}, function (error) {

			}
		);
	}

	plantAssetTabcontent.onSiteSelected = function () {
		if (plantAssetTabcontent.currentTab != mapping.stateParams.tabSite) {
			console.log(plantAssetTabcontent.selectedSite);
			plantAssetService.getPlantBySite(plantAssetTabcontent.selectedSite).then(
				function (response) {
					plantAssetTabcontent.filterPlants = response.result.data;
				}, function (error) {

				}
			);
		}

	}

	plantAssetTabcontent.onPlantSelected = function () {
		if (plantAssetTabcontent.currentTab != mapping.stateParams.tabBlock) {
			console.log(plantAssetTabcontent.selectedPlant);
			plantAssetService.getBlockByPlant(plantAssetTabcontent.selectedPlant).then(
				function (response) {
					plantAssetTabcontent.filterBlocks = response.result.data;
				}, function (error) {

				}
			);
		}

	}

	plantAssetTabcontent.onBlockSelected = function () {
		if (plantAssetTabcontent.currentTab != mapping.stateParams.tabUnit) {
			console.log(plantAssetTabcontent.selectedBlock);
			plantAssetService.getUnitByBlock(plantAssetTabcontent.selectedBlock).then(
				function (response) {
					plantAssetTabcontent.filterUnits = response.result.data;
				}, function (error) {

				}
			);
		}
	}

	plantAssetTabcontent.onUnitSelected = function () {
		if (plantAssetTabcontent.currentTab != mapping.stateParams.tabAsset) {
			console.log(plantAssetTabcontent.selectedUnit);
			plantAssetService.getAssetByUnit(plantAssetTabcontent.selectedUnit).then(
				function (response) {
					plantAssetTabcontent.filterAssets = response.result.data;
				}, function (error) {

				}
			);
		}
	}

	plantAssetTabcontent.onAssetSelected = function () {
		console.log(plantAssetTabcontent.selectedAsset);
	}

	plantAssetTabcontent.pagination = mapping.pagination;
	plantAssetTabcontent.pageChanged = function() {
		console.log(plantAssetTabcontent.currentPage + "," + plantAssetTabcontent.totalItems);
	}

}
plantAssetTabcontentOperationController.$inject = ['$scope', '$rootScope', '$state', 'plantAssetService', '$stateParams', 'mapping'];
module.exports = plantAssetTabcontentOperationController;