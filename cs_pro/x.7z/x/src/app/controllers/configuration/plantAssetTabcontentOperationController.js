
var plantAssetTabcontentController = function ($scope, $rootScope, $state, plantAssetService, $stateParams, mapping) {

	var plantAssetTabcontentOperation = this;

	var operation = $stateParams.operation;
	var currentTab = $stateParams.tab;

plantAssetTabcontentOperation.relations = {
		"siteId": {
			"title": "Site",
			"model": mapping.stateParams.tabSite,
			"exist": false,
			"selected": 0,
			"list": [],
			"relation": "plantId"
		},
		"plantId": {
			"title": "Plant",
			"model": mapping.stateParams.tabPlant,
			"exist": false,
			"selected": 0,
			"list": [],
			"relation": "blockId"
		},
		"blockId": {
			"title": "Block",
			"model": mapping.stateParams.tabBlock,
			"exist": false,
			"selected": 0,
			"list": [],
			"relation": "unitId"
		},
		"unitId": {
			"title": "Unit",
			"model": mapping.stateParams.tabUnit,
			"exist": false,
			"selected": 0,
			"list": [],
			"relation": "assetId"
		},
		"assetId": {
			"title": "Asset",
			"model": mapping.stateParams.tabAsset,
			"exist": false,
			"selected": 0,
			"list": [],
			"relation": "tagId"
		}
	}

	function filtRelations() {
		for (item in plantAssetTabcontentOperation.relations) {
			var rel = plantAssetTabcontentOperation.detail[item];
			if (typeof (rel) != undefined && rel != null) {
				plantAssetTabcontentOperation.relations[item].exist = true;
				plantAssetTabcontentOperation.relations[item].selected = rel;
				if (rel > 0) {
					if (plantAssetTabcontentOperation.relations[item].model == mapping.stateParams.tabSite) {
						getSiteSelections(item);
					} else {
						getSelections(item, rel);
					}
				} else {
					if (plantAssetTabcontentOperation.relations[item].model == mapping.stateParams.tabSite) {
						getSiteSelections(item);
					}
				}

			}
		}

	}

	function getSiteSelections(item) {
		plantAssetService.getSites().then(
			function (response) {
				angular.forEach(response.result.data, function (element) {
					plantAssetTabcontentOperation.relations[item].list.push(element);
				}, this);
			}, function (error) {

			}
		);
	}

	function getSelections(item, rel) {
		plantAssetService.getSingleRelationList(plantAssetTabcontentOperation.relations[item].model, rel).then(
			function (response) {
				plantAssetTabcontentOperation.relations[item].list.splice(0, plantAssetTabcontentOperation.relations[item].list.length);
				angular.forEach(response.result.data, function (element) {
					plantAssetTabcontentOperation.relations[item].list.push(element);
				}, this);
			}, function (error) {

			}
		);
	}

	if (operation == mapping.roleOperations.createRole) {
		var userId = $rootScope.auther.data.id;
		plantAssetTabcontentOperation.creationsTemplate = {
			"tabSite": {
				"name": "",
				"abbreviation": "",
				"description": "",
				"lastModifierUserId": userId,
				"lastModificationTime": "",
				"id": 0
			}, "tabPlant": {
				"name": "",
				"abbreviation": "",
				"description": "",
				"lastModifierUserId": userId,
				"lastModificationTime": "",
				"siteId": 0,
				"id": 0
			}, "tabBlock": {
				"name": "",
				"abbreviation": "",
				"description": "",
				"lastModifierUserId": userId,
				"lastModificationTime": "",
				"siteId": 0,
				"plantId": 0,
				"id": 0
			}, "tabUnit": {
				"name": "",
				"abbreviation": "",
				"description": "",
				"lastModifierUserId": userId,
				"lastModificationTime": "",
				"siteId": 0,
				"plantId": 0,
				"blockId": 0,
				"id": 0
			}, "tabAsset": {
				"name": "",
				"abbreviation": "",
				"description": "",
				"lastModifierUserId": userId,
				"lastModificationTime": "",
				"siteId": 0,
				"plantId": 0,
				"blockId": 0,
				"unitId": 0,
				"id": 0
			}
		}
		plantAssetTabcontentOperation.detail = plantAssetTabcontentOperation.creationsTemplate[currentTab];
		filtRelations();
	} else {
		plantAssetService.obtainModelBy(currentTab, $stateParams.id).then(
			function (response) {
				plantAssetTabcontentOperation.detail = response.result.data;
				filtRelations();
			}, function (error) {

			}
		);
	}


	plantAssetTabcontentOperation.isEidtion = function () {
		return operation == mapping.roleOperations.editRole;
	}

	var configurationApis = mapping.configurationApis;
	plantAssetTabcontentOperation.create = function () {
		var bind = plantAssetTabcontentOperation.relations[configurationApis[currentTab].relation].selected;
		console.log(plantAssetTabcontentOperation.detail);
		console.log("create bind before " + plantAssetTabcontentOperation.detail[configurationApis[currentTab].relation]);
		plantAssetTabcontentOperation.detail[configurationApis[currentTab].relation] = bind;
		console.log("create bind " + plantAssetTabcontentOperation.detail[configurationApis[currentTab].relation]);
		plantAssetService.create(currentTab, plantAssetTabcontentOperation.detail);
	}

	plantAssetTabcontentOperation.edit = function () {
		var bind = plantAssetTabcontentOperation.relations[configurationApis[currentTab].relation].selected;
		//console.log("edit bind before " + plantAssetTabcontentOperation.detail[configurationApis[currentTab].relation]);
		plantAssetTabcontentOperation.detail[configurationApis[currentTab].relation] = bind;
		//console.log("edit bind " + configurationApis[currentTab].relation + "," + plantAssetTabcontentOperation.detail[configurationApis[currentTab].relation]);
		plantAssetService.update(currentTab, plantAssetTabcontentOperation.detail).then(
			function (response) {
				plantAssetTabcontentOperation.goBack();
			}, function (error) {

			}
		);

	}

	plantAssetTabcontentOperation.onSelectionChanged = function (item) {
		var relationBy = plantAssetTabcontentOperation.relations[item.relation];
		console.log("relationBy " + item.relation + "," + item.selected);
		if (relationBy.exist) {
			// request 
			relationBy.selected = 0;
			getSelections(item.relation, item.selected);
			cleanAfter(relationBy);
		}

	}

	function cleanAfter(current) {
		var next = plantAssetTabcontentOperation.relations[current.relation];
		if (typeof (next) != undefined && next != null && next.exist) {
			next.selected = 0;
			var ls = next.list;
			ls.splice(0, ls.length);
			console.log(ls);
			cleanAfter(next);
		}
	}

	plantAssetTabcontentOperation.goBack = function () {
		$scope.$emit("showList", "");
	}

}
plantAssetTabcontentController.$inject = ['$scope', '$rootScope', '$state', 'plantAssetService', '$stateParams', 'mapping'];
module.exports = plantAssetTabcontentController;