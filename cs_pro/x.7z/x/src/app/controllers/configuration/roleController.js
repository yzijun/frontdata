
var roleController = function ($scope, $rootScope, $state, mapping, roleService) {
    console.log('main');
    var role = this;

    //role.list = {};
    roleService.obtainRoles().then(
        function (response) {
            console.log("success");
            role.list = response.result.data;
        },
        function (error) {
            console.log("error");
        }
    );

    role.isShrinked = false;
    role.create = function () {
        role.isShrinked = true;
        console.log("create role " + role.isShrinked);
        $state.go("main.configuration-role.operations"
            , {"id": 0, "operation": mapping.roleOperations.createRole})
    }

    role.edit = function ($event, item) {
        role.isShrinked = true;
        console.log("edit role " + role.isShrinked);
        $event.stopPropagation();
        $state.go("main.configuration-role.operations"
            , {"id": item.id, "operation": mapping.roleOperations.editRole})
    }

    role.showDetail = function (item) {
        role.isShrinked = true;
        console.log("show role " + role.isShrinked);
        $state.go("main.configuration-role.operations"
            , {"id": item.id, "operation": mapping.roleOperations.checkDetail})
    }

    $scope.$on('expandList', function (d, data) {
        role.isShrinked = false;
        console.log("expandList " + role.isShrinked);
    })

}
roleController.$inject = ['$scope', '$rootScope', '$state', 'mapping', 'roleService'];
module.exports = roleController;