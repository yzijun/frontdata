
var messageOperationController = function ($scope, $rootScope, $state, $stateParams, mapping, messageConfService) {
	console.log('messageOperation');
	var messageOperation = this;
	messageOperation.operation = $stateParams.operation;
  messageOperation.reference = mapping.roleOperations;

	messageConfService.obtainMasterData($stateParams.id).then(
		function (response) {
			messageOperation.detail = response.result.data;
			console.log("success");
		},
		function (error) {
			console.log("error");
		}
	);


	messageOperation.edit = function () {
		messageConfService.updateMasterData(messageOperation.detail).then(
			function (response) {
				console.log("success");
				messageOperation.close();
			},
			function (error) {
				console.log("error");
			}
		);
	}

	messageOperation.close = function () {
		console.log("close");
		$scope.$emit("expandList", "");
		$state.go("main.configuration-message");
	}
}
messageOperationController.$inject = ['$scope', '$rootScope', '$state', '$stateParams', 'mapping', 'messageConfService'];
module.exports = messageOperationController;