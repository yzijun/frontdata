
var messageController = function ($scope, $rootScope, $state, mapping, messageConfService) {
	console.log('message');
	var message = this;
	message.isShrinked = false;

	messageConfService.obtainMasterDatas().then(
		function (response) {
			message.list = response.result.data;
		}, function (error) {
			console.log("error message");
		}
	);

	message.edit = function ($event, item) {
		message.isShrinked = true;
		console.log("edit message " + message.isShrinked);
		$event.stopPropagation();
		$state.go("main.configuration-message.operations"
			, { "id": item.id , "operation": mapping.roleOperations.editRole})
	}

	message.showDetail = function (item) {
		message.isShrinked = true;
		console.log("show message " + message.isShrinked);
		$state.go("main.configuration-message.operations"
			, { "id": item.id , "operation": mapping.roleOperations.checkDetail})
	}

	$scope.$on('expandList', function (d, data) {
		message.isShrinked = false;
		console.log("expandList " + message.isShrinked);
	})
}
messageController.$inject = ['$scope', '$rootScope', '$state', 'mapping', 'messageConfService'];
module.exports = messageController;