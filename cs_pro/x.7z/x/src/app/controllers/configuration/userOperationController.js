
var userOperationController = function ($scope, $rootScope, $state, $stateParams, mapping, userService) {
    console.log('user');
    var userOperation = this;
    userOperation.operation = $stateParams.operation;
    userOperation.reference = mapping.roleOperations;
    userOperation.fileRootUrl = mapping.urls.fileRootUrl;


    userService.obtainRoles().then(
        function (response) {
            userOperation.pureRoles = response.result.data;
            angular.forEach(userOperation.pureRoles, function (element) {
                element["wrapperChecked"] = false;
            }, this);
            resetRoleList();
        }, function (error) {
            console.log("error on get roles");
        }
    );

    userService.getPlants().then(
        function (response) {
            console.log("get plants sucess");
            userOperation.plants = response.result.data;
        }, function (error) {
            console.log("error on get plants");
        }
    );

    if (userOperation.operation == userOperation.reference.editRole) {
        userService.obtainUser($stateParams.id).then(
            function (response) {
                console.log("userOperation.operation : " + userOperation.operation);
                console.log("userOperation.reference : " + userOperation.reference.editRole);
                userOperation.detail = response.result.data;
                angular.forEach(userOperation.roles, function (element) {
                    for (var index = 0; index < userOperation.detail.roles.length; index++) {
                        var role = userOperation.detail.roles[index];
                        if (element.id == role) {
                            element.wrapperChecked = true;
                            userOperation.detail.roles.splice(index, 1);
                            break;
                        }
                    }
                }, this);
            }, function (error) {
                console.log("error on get user");
            }
        );
    } else {
        userOperation.detail = {};
    }

    function resetRoleList() {
        userOperation.roles = angular.copy(userOperation.pureRoles);
    }

    userOperation.onImgSelected = function ($file) {
        if ($file) {
            var fileReader = new FileReader();
            fileReader.readAsDataURL($file);
            fileReader.onload = function (e) {
                var base64Data = e.target.result.substr(e.target.result.indexOf('base64,') + 'base64,'.length);
                userService.uploadImg($file, base64Data).then(
                    function (response) {
                        userOperation.detail.imgUrl = response.result.imgUrl;
                    }, function (error) {

                    }
                );
            };
        }
    }

    userOperation.createUser = function () {
        var array = [];
        angular.forEach(userOperation.roles, function (element) {
            if (element.wrapperChecked) {
                array.push(element.id);
            }
        }, this);
        userOperation.detail.roles = array;

        userService.createUser(userOperation.detail).then(
            function (response) {
                backToList();
            }, function (error) {

            }
        );
    }

    userOperation.cancel = function () {
        backToList();
    }

    function backToList() {
        $scope.$emit("showList", "");
        $state.go("main.configuration-user");
    }

}
userOperationController.$inject = ['$scope', '$rootScope', '$state', '$stateParams', 'mapping', 'userService'];
module.exports = userOperationController;