
var kpiController = function ($scope, $rootScope, $state, mapping, kpiConfService) {
	var kpi = this;
	kpi.isShrinked = false;

	kpiConfService.obtainKpiLsit().then(
		function (response) {
			kpi.list = response.result.data;
			console.log(JSON.stringify(kpi.list) + "---------kpiList")
		}, function (error) {
			console.log("error kpi");
		}
	);

	kpi.edit = function ($event, item) {
		kpi.isShrinked = true;
		console.log("edit kpi " + kpi.isShrinked);
		$event.stopPropagation();
		$state.go("main.configuration-kpi.operations"
			, { "id": item.id , "operation": mapping.roleOperations.editRole})
	}

	kpi.showDetail = function (item) {
		kpi.isShrinked = true;
		console.log("show kpi " + kpi.isShrinked);
		$state.go("main.configuration-kpi.operations"
			, { "id": item.id , "operation": mapping.roleOperations.checkDetail})
	}

	$scope.$on('expandList', function (d, data) {
		kpi.isShrinked = false;
		console.log("expandList " + kpi.isShrinked);
	})
}
kpiController.$inject = ['$scope', '$rootScope', '$state', 'mapping', 'kpiConfService'];
module.exports = kpiController;