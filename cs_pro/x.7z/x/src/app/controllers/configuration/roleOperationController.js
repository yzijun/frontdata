
var roleOperationController = function ($scope, $rootScope, $state, $stateParams, mapping, roleService) {
    console.log('roleOperationController : ' + $stateParams.operation + "," + $stateParams.id);
    var roleOperation = this;
    roleOperation.operation = $stateParams.operation;
    roleOperation.reference = mapping.roleOperations;
    if (roleOperation.operation == roleOperation.reference.createRole) {
        roleOperation.newRole = {
            "name" : "",
            "description" : "",
            "imgUrl" : "",
            "status" : true
        }
    } else if (roleOperation.operation == roleOperation.reference.checkDetail) {
        getDetail($stateParams.id);
    } else if (roleOperation.operation == roleOperation.reference.editRole) {
        getDetail($stateParams.id);
    }

    function getDetail(role) {
        roleService.obtainRoleDetail(role).then(
            function (response) {
                roleOperation.detail = response.result.data;
                console.log("success");
            },
            function (error) {
                console.log("error");
            }
        );
    }

    roleOperation.createRole = function() {
        roleService.createRole(roleOperation.newRole).then(
            function (response) {
                console.log("success");
                roleOperation.close();
            },
            function (error) {
                console.log("error");
            }
        );
    }

    roleOperation.editRole = function() {
        roleService.updateRole(roleOperation.detail).then(
            function (response) {
                console.log("success");
                roleOperation.close();
            },
            function (error) {
                console.log("error");
            }
        );
    }
    
    roleOperation.close = function () {
        $scope.$emit("expandList", "");
        $state.go("main.configuration-role");
    }

}
roleOperationController.$inject = ['$scope', '$rootScope', '$state', '$stateParams', 'mapping', 'roleService'];
module.exports = roleOperationController;