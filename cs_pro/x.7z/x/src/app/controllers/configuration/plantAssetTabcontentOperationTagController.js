
var plantAssetTabcontentOperationTag = function ($scope, $rootScope, $state, plantAssetService, $stateParams, mapping) {

	var plantAssetTabcontentOperationTag = this;
	var currentTab = mapping.stateParams.tabTag;
	plantAssetTabcontentOperationTag.accuracy = mapping.accuracy;
	plantAssetTabcontentOperationTag.metricImperial = mapping.measurement;

	plantAssetService.obtainModelBy(currentTab, $stateParams.id).then(
		function (response) {
			plantAssetTabcontentOperationTag.detail = response.result.data;
			getSites();
		}, function (error) {

		}
	);

	function getSites() {
		plantAssetService.getSites().then(
			function (response) {
				plantAssetTabcontentOperationTag.siteSelections = response.result.data;
				if (plantAssetTabcontentOperationTag.detail) {
					for (var index = 0; index < plantAssetTabcontentOperationTag.siteSelections.length; index++) {
						var element = plantAssetTabcontentOperationTag.siteSelections[index];
						if (plantAssetTabcontentOperationTag.detail.siteId == element.id) {
							plantAssetTabcontentOperationTag.selectedSite = element;
							matchPlant();
							break;
						}
					}
				}

			}, function (error) {

			}
		)
	}

	function matchPlant() {
		plantAssetService.getPlantBySite(plantAssetTabcontentOperationTag.selectedSite.id).then(
			function (response) {
				plantAssetTabcontentOperationTag.plantSelections = response.result.data;
				if (plantAssetTabcontentOperationTag.detail) {
					for (var index = 0; index < plantAssetTabcontentOperationTag.plantSelections.length; index++) {
						var element = plantAssetTabcontentOperationTag.plantSelections[index];
						if (plantAssetTabcontentOperationTag.detail.plantId == element.id) {
							plantAssetTabcontentOperationTag.selectedPlant = element;
							matchBlock();
							break;
						}
					}
				}
			}, function (error) {

			}
		);
	}

	function matchBlock() {
		plantAssetService.getBlockByPlant(plantAssetTabcontentOperationTag.selectedPlant.id).then(
			function (response) {
				plantAssetTabcontentOperationTag.blockSelections = response.result.data;
				if (plantAssetTabcontentOperationTag.detail) {
					for (var index = 0; index < plantAssetTabcontentOperationTag.blockSelections.length; index++) {
						var element = plantAssetTabcontentOperationTag.blockSelections[index];
						if (plantAssetTabcontentOperationTag.detail.blockId == element.id) {
							plantAssetTabcontentOperationTag.selectedBlock = element;
							matchUnit();
							break;
						}
					}
				}
			}, function (error) {

			}
		);
	}

	function matchUnit() {
		plantAssetService.getUnitByBlock(plantAssetTabcontentOperationTag.selectedBlock.id).then(
			function (response) {
				plantAssetTabcontentOperationTag.unitSelections = response.result.data;
				if (plantAssetTabcontentOperationTag.detail) {
					for (var index = 0; index < plantAssetTabcontentOperationTag.unitSelections.length; index++) {
						var element = plantAssetTabcontentOperationTag.unitSelections[index];
						if (plantAssetTabcontentOperationTag.detail.unitId == element.id) {
							plantAssetTabcontentOperationTag.selectedUnit = element;
							if (plantAssetTabcontentOperationTag.detail.type == "0") {
								plantAssetTabcontentOperationTag.selectedUnitAsset = plantAssetTabcontentOperationTag.u + element.id;
							}
							matchAsset();
							break;
						}
					}
				}
			}, function (error) {

			}
		);
	}

	function matchAsset() {
		plantAssetService.getAssetByUnit(plantAssetTabcontentOperationTag.selectedUnit.id).then(
			function (response) {
				plantAssetTabcontentOperationTag.assetSelections = response.result.data;
				if (plantAssetTabcontentOperationTag.detail) {
					for (var index = 0; index < plantAssetTabcontentOperationTag.assetSelections.length; index++) {
						var element = plantAssetTabcontentOperationTag.assetSelections[index];
						if (plantAssetTabcontentOperationTag.detail.assetId == element.id) {
							if (plantAssetTabcontentOperationTag.detail.type == "1") {
								plantAssetTabcontentOperationTag.selectedUnitAsset = plantAssetTabcontentOperationTag.a + element.id;
							}
							break;
						}
					}
				}
			}, function (error) {

			}
		);
	}



	plantAssetTabcontentOperationTag.onSiteChecked = function (site) {
		// clear plant unit asset
		plantAssetTabcontentOperationTag.selectedSite = site;
		plantAssetService.getPlantBySite(site.id).then(
			function (response) {
				plantAssetTabcontentOperationTag.plantSelections = response.result.data;
			}, function (error) {

			}
		);
	}

	plantAssetTabcontentOperationTag.onPlantChecked = function (plant) {
		// clear plant unit asset
		plantAssetTabcontentOperationTag.selectedPlant = plant;
		plantAssetService.getBlockByPlant(plant.id).then(
			function (response) {
				plantAssetTabcontentOperationTag.blockSelections = response.result.data;
			}, function (error) {

			}
		);
	}

	plantAssetTabcontentOperationTag.onBlockChecked = function (block) {
		// clear plant unit asset
		plantAssetTabcontentOperationTag.selectedBlock = block;
		plantAssetService.getUnitByBlock(block.id).then(
			function (response) {
				plantAssetTabcontentOperationTag.unitSelections = response.result.data;
			}, function (error) {

			}
		);
	}

	plantAssetTabcontentOperationTag.u = "u";
	plantAssetTabcontentOperationTag.onUnitChecked = function (unit) {
		// clear plant unit asset
		plantAssetTabcontentOperationTag.selectedUnitAsset = plantAssetTabcontentOperationTag.u + unit.id;
		plantAssetService.getAssetByUnit(unit.id).then(
			function (response) {
				plantAssetTabcontentOperationTag.assetSelections = response.result.data;
			}, function (error) {

			}
		);
	}

	plantAssetTabcontentOperationTag.a = "a";
	plantAssetTabcontentOperationTag.onAssetChecked = function (asset) {
		// clear plant unit asset
		plantAssetTabcontentOperationTag.selectedUnitAsset = plantAssetTabcontentOperationTag.a + asset.id;
	}

	plantAssetTabcontentOperationTag.isEidtion = function () {
		return true;
	}

	plantAssetTabcontentOperationTag.edit = function () {
		if ($rootScope.auther) {
			plantAssetTabcontentOperationTag.detail = $rootScope.auther.data.id;
		}
		plantAssetTabcontentOperationTag.detail.siteId = plantAssetTabcontentOperationTag.selectedSite.id;
		plantAssetTabcontentOperationTag.detail.plantId = plantAssetTabcontentOperationTag.selectedPlant.id;
		plantAssetTabcontentOperationTag.detail.blockId = plantAssetTabcontentOperationTag.selectedBlock.id;
		if (plantAssetTabcontentOperationTag.selectedUnitAsset.indexOf(plantAssetTabcontentOperationTag.u) == 0) {
			plantAssetTabcontentOperationTag.detail.unitId = plantAssetTabcontentOperationTag.selectedUnitAsset.substring(1, plantAssetTabcontentOperationTag.selectedUnitAsset.length);
			plantAssetTabcontentOperationTag.detail.type = 0;
			plantAssetTabcontentOperationTag.detail.typeValue = plantAssetTabcontentOperationTag.detail.unitId;
		}else if (plantAssetTabcontentOperationTag.selectedUnitAsset.indexOf(plantAssetTabcontentOperationTag.a) == 0) {
			plantAssetTabcontentOperationTag.detail.assetId = plantAssetTabcontentOperationTag.selectedUnitAsset.substring(1, plantAssetTabcontentOperationTag.selectedUnitAsset.length);
			plantAssetTabcontentOperationTag.detail.type = 1;
			plantAssetTabcontentOperationTag.detail.typeValue = plantAssetTabcontentOperationTag.detail.assetId;
		}
		plantAssetService.update(currentTab, plantAssetTabcontentOperationTag.detail).then(
			function (response) {
				plantAssetTabcontentOperationTag.goBack();
			}, function (error) {

			}
		);

	}

	plantAssetTabcontentOperationTag.onSelectionChanged = function (item) {

	}

	function cleanAfter(current) {

	}

	plantAssetTabcontentOperationTag.goBack = function () {
		$scope.$emit("showList", "");
	}

}
plantAssetTabcontentOperationTag.$inject = ['$scope', '$rootScope', '$state', 'plantAssetService', '$stateParams', 'mapping'];
module.exports = plantAssetTabcontentOperationTag;