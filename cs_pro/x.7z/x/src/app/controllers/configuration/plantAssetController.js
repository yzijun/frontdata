
var plantAssetController = function ($scope, $rootScope, $state, plantAssetService, mapping) {
	console.log('plantAsset');
	var plantAsset = this;

	plantAsset.tabTitles = [
		{
			"name": "Site",
			"route": mapping.stateParams.tabSite
		}, {
			"name": "Plant",
			"route": mapping.stateParams.tabPlant
		}, {
			"name": "Block",
			"route": mapping.stateParams.tabBlock
		}, {
			"name": "Unit",
			"route": mapping.stateParams.tabUnit
		}, {
			"name": "Asset",
			"route": mapping.stateParams.tabAsset
		}, {
			"name": "Tag",
			"route": mapping.stateParams.tabTag
		}
	];
	plantAsset.goTab = function (item) {
		$state.go("main.configuration-plantAsset.tabcontent", { "tab": item.route });
	}
	$state.go("main.configuration-plantAsset.tabcontent", { "tab": mapping.stateParams.tabSite });
}
plantAssetController.$inject = ['$scope', '$rootScope', '$state', 'plantAssetService', 'mapping'];
module.exports = plantAssetController;