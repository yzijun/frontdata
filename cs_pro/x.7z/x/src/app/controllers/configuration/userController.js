 
var userController = function($scope, $rootScope, $state, mapping, userService) {
	console.log('userScope');
	var userScope = this;
 	userScope.isListShown = true;
	userService.obtainUsers().then(
        function (response) {
            console.log("success");
            userScope.list = response.result.data;
        },
        function (error) {
            console.log("error");
        }
    );
	userScope.create = function() {
		console.log("create user");
		userScope.isListShown = false;
		console.log("create user " + userScope.isListShown);
		$state.go("main.configuration-user.operations"
            , {"id": 0, "operation": mapping.roleOperations.createRole});
	}

    userScope.edit = function($event, user) {
		$event.stopPropagation();
		userScope.isListShown = false;
		console.log("edit user " + userScope.isListShown);
		$state.go("main.configuration-user.operations"
            , {"id": user.id, "operation": mapping.roleOperations.editRole});
	}

	userScope.isDetailShown = false;
    userScope.showDetail = function(user) {
		userScope.isDetailShown = true;
		console.log("show user " + userScope.isDetailShown);
		userScope.detail = user;
	}
	userScope.closeDetail = function() {
		console.log("dismiss detail");
		userScope.isDetailShown = false;
	}

	$scope.$on('showList', function (d, data) {
        userScope.isListShown = true;
        console.log("show list " + userScope.isListShown);
    })
}
userController.$inject = ['$scope', '$rootScope', '$state', 'mapping', 'userService'];
module.exports = userController;