
var permissionController = function ($scope, $rootScope, $state, permissionService) {
	console.log('permission');
	var permission = this;

	permission.outer = 0;
	//get all permissions
	permissionService.getPermissions().then(
		function (response) {
			permission.permissionPureList = response.result.data;
			angular.forEach(permission.permissionPureList, function (element) {
				var reses = element.resources;
				element["wrapperChecked"] = false;
				element["isToggled"] = false;
				angular.forEach(reses, function (resElement) {
					resElement["wrapperChecked"] = false;
					var opers = resElement.operations;
					angular.forEach(opers, function (operElement) {
						operElement["wrapperChecked"] = false;
					}, this);
				}, this);
			}, this);
			resetPermissionList();
			console.log("get all permission " + permission.permissionList);
		}, function (error) {
			console.log("get all permission error");
		}
	);

	function resetPermissionList() {
		permission.permissionList = angular.copy(permission.permissionPureList);
	}

	//get all roles
	permissionService.getAllRoles().then(
		function (response) {
			permission.allRoles = response.result.data;
			console.log("get roles all " + permission.allRoles);
			markDefaultBelongPermission();
		}, function (error) {
			console.log("get roles all error");
		}
	);

	// set default by current user
	permission.selectedRole = null;

	function markDefaultBelongPermission() {
		if (permission.permissionList != "undefined" && permission.allRoles.length > 0) {
			permission.selectedRole = permission.allRoles[0].id;
			permission.getPermissionByRole(permission.selectedRole);
		}

	}

	//get permission by role
	permission.getPermissionByRole = function (role) {
		console.log(role);
		permission.selectedRole = role;
		permissionService.getPermissionByRole(role).then(
			function (response) {
				permission.permissionRole = response.result.data;
				console.log("getPermissionByRole " + permission.permissionRole);
				setBelongPermission();
			}, function (error) {
				console.log("getPermissionByRole error");
			}
		);
	}

	function setBelongPermission() {
		if (permission.permissionRole != "undefined") {
			resetPermissionList();
			var modules = permission.permissionRole.moduleIdList;
			var menus = permission.permissionRole.resourceIdList;
			var actions = permission.permissionRole.opreationIdList;
			if (modules != null) {
				angular.forEach(permission.permissionList, function (element) {
					for (var index = 0; index < modules.length; index++) {
						if (modules[index] == element.id) {
							element.wrapperChecked = true;
							modules.splice(index, 1);
							break;
						}
					}
					if (menus != null) {
						angular.forEach(element.resources, function (resElement) {
							for (var i = 0; i < menus.length; i++) {
								if (menus[i] == resElement.id) {
									resElement.wrapperChecked = true;
									menus.splice(i, 1);
									break;
								}
							}
							if (actions != null) {
								angular.forEach(resElement.operations, function (operElement) {
									for (var j = 0; j < actions.length; j++) {
										if (actions[j] == operElement.id) {
											operElement.wrapperChecked = true;
											actions.splice(j, 1);
											break;
										}
									}
								}, this);
							}
						}, this);
					}
				}, this);
			}
			console.log("permission " + permission.permissionList);
		}
	}

	permission.toggleAll = function(permissionModule) {
		permissionModule.wrapperChecked = permissionModule.isToggled;
		angular.forEach(permissionModule.resources, function(resource) {
			resource.wrapperChecked = permissionModule.isToggled;
			angular.forEach(resource.operations, function(operation) {
				operation.wrapperChecked = permissionModule.isToggled;
			}, this);
		}, this);
	}

	permission.onMenuClick = function(permissionModule, menu) {
		// console.log("module : " + permissionModule.id + " ;menu : " + menu.id + ",status : " + menu.wrapperChecked);
		if (!menu.wrapperChecked) {
			var list = menu.operations;
			angular.forEach(list, function(element) {
				element.wrapperChecked = false;
			}, this);
			var flag = false;
			for (var i = 0; i < permissionModule.resources.length; i++) {
				flag |= permissionModule.resources[i].wrapperChecked;
				if (flag) {
					break;
				}
			}
			if (!flag) {
				permissionModule.wrapperChecked = false;
			}
		} else {
			permissionModule.wrapperChecked = true;
		}
	}

	permission.onActionClick = function(menu, action) {
		// console.log("module : " + menu.id + " ;action : " + action.id + ",status : " + action.wrapperChecked);
		if (action.wrapperChecked && !menu.wrapperChecked) {
			menu.wrapperChecked = true;
		} 
	}

	

	permission.save = function () {
		console.log("permission save"  + permission.permissionList);
		if (permission.selectedRole != null) {
			var moduls = [];
			var menus = [];
			var actions = [];
			angular.forEach(permission.permissionList, function (element) {
				if (element.wrapperChecked) {
					moduls.push(element.id);
					angular.forEach(element.resources, function (resElement) {
						if (resElement.wrapperChecked) {
							menus.push(resElement.id);
							angular.forEach(resElement.operations, function (operElement) {
								if (operElement.wrapperChecked) {
									actions.push(operElement.id);
								}
							}, this);
						}
					}, this);
				}
			}, this);
			if (moduls.length > 0) {
				permissionService.updateRolePermissions(permission.selectedRole
					, moduls , menus , actions).then(
					function (response) {
						console.log("save success " + response);
					}, function (error) {
						console.log("save failure");
					}
				);
			}
			
		}
	}
}
permissionController.$inject = ['$scope', '$rootScope', '$state', 'permissionService'];
module.exports = permissionController;