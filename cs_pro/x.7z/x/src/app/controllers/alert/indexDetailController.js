var indexDetailCtrl = function($rootScope, $scope, $state, $stateParams, alertService, mapping) {
    var alertDetail = this;

    // 取得详细数据
    function getAlert() {
        alertService.getAlertById({ id: $stateParams.id }).then(
            function(response) {
                alertDetail.alert = response.result.data;
                // symptoms 创建case用字段
                alertDetail.alert.symptoms = "";
                // 设置severity默认下拉选项
                alertDetail.alert.severities = mapping.severity;
                // console.log(alertDetail.alert);
            }
        );
    }

    getAlert();

    // 取得evidences数据
    function getEvidences() {
        alertService.getEvidences({ typeValue: $stateParams.id, type: 0 }).then(
            function(response) {
                alertDetail.evidences = response.result.data;
                // console.log(alertDetail.evidences);
            }
        );
    }

    getEvidences();


    // 上传图片参数
    alertDetail.upficparam = {
        // type 0 = alert
        type: 0,
        // typeValue = alertID
        typeValue: $stateParams.id,
        // loginID
        creatorUserId: $rootScope.auther.data.id,
        // username
        userName: $rootScope.auther.data.name,
        message: 'Uploaded evidence this alert.'
    }

    // 上传图片转换base64
    alertDetail.setImg = function($file, param) {
        if ($file && $file.$error == 'pattern') {
            return;
        }
        if ($file) {
            var fileReader = new FileReader();
            fileReader.readAsDataURL($file);
            fileReader.onload = function(e) {
                var base64Data = e.target.result.substr(e.target.result.indexOf('base64,') + 'base64,'.length);
                $scope.$apply(function() {
                    param.fileData = base64Data;
                    // param.fileType = $file.type;
                    param.name = $file.name;
                    alertService.getFileType(param);

                    alertDetail.uploadPic();
                });
            };
        }
    }

    // upload evidence 上传图片
    alertDetail.uploadPic = function() {
        alertService.detailUploadPic(alertDetail.upficparam).then(
            function(response) {
                if (response.result.isCreated) {
                    // 更新evidence
                    getEvidences();
                    // 更新log
                    getLogs();
                }
            }
        );
    }

    // 取得note数据
    function getNotes() {
        alertService.getNotes({ alertId: $stateParams.id }).then(
            function(response) {
                alertDetail.notes = response.result.data;
                // console.log("getNotes", alertDetail.notes);
            }
        );
    }

    getNotes();

    // 创建note数据
    alertDetail.note = "";
    alertDetail.createNote = function() {
        alertDetail.isSavingNote = true;
        alertService.createNote({
            typeValue: $stateParams.id,
            type: 0,
            text: alertDetail.note,
            // loginID
            creatorUserId: $rootScope.auther.data.id,
            // username
            userName: $rootScope.auther.data.name,
            message: 'Created note this alert.'
        }).then(
            function(response) {
                // 创建成功
                if (response.result.isCreated) {
                    alertDetail.isSavingNote = false;
                    // alertDetail.note = " ";
                    getNotes();
                    // 更新log
                    getLogs();
                }
            }
        );
    }

    // 显示evidence图片
    alertDetail.showPic = function(url) {
        //设置服务器地址
        url = mapping.urls.fileRootUrl + url;
        $("#upload-panel img").attr('src', url);
    }

    // 更新alert状态
    alertDetail.updateAlertStatus = function(st, name) {
        // 设置状态名称
        $("#statusName").html(name);
        alertService.updateAlertStatus({
            typeValue: $stateParams.id,
            // 登录ID
            ownId: $rootScope.auther.data.id,
            status: st,
            id: $stateParams.id,
            // loginID
            creatorUserId: $rootScope.auther.data.id,
            // username
            userName: $rootScope.auther.data.name,
            message: st == 2 ? 'Claimed this alert.' : 'Closed this alert.'
        }).then(
            function(response) {
                if (response.result.isSaved) {
                    // 更新alert详细数据
                    getAlert();
                    // 更新log
                    getLogs();
                }
            }
        );
    }

    // 创建case
    alertDetail.createCase = function() {
        // 关闭popup
        $("#modal-case").modal('hide');

        alertService.createCase({
            caseName: alertDetail.alert.alertName,
            symptoms: alertDetail.alert.symptoms,
            severity: alertDetail.alert.severity,
            resource: 1,
            plantName: alertDetail.alert.plantName,
            assetName: alertDetail.alert.assetName,
            unitName: alertDetail.alert.unitName,
            // 登录ID
            creatorUserId: $rootScope.auther.data.id,
            alertId: $stateParams.id,
            typeValue: $stateParams.id,
            // username
            userName: $rootScope.auther.data.name,
            message: 'Created case this alert.'
        }).then(
            function(response) {
                if (response.result.isCreated) {
                    // 更新log
                    getLogs();
                }
            }
        );
    }

    // 显示创建case
    alertDetail.showCreattingCase = function(name) {
        // 设置状态名称
        $("#statusName").html(name);
        // 更新alert详细数据
        getAlert();
    }

    // 取得log数据
    function getLogs() {
        alertService.getLogs({ typeValue: $stateParams.id, type: 0 }).then(
            function(response) {
                alertDetail.logs = response.result.data;
                // console.log(alertDetail.logs);
            }
        );
    }

    getLogs();

    // 回到列表页
    alertDetail.backList = function() {
        $scope.$emit('dismissDetail', '');
    };

};
indexDetailCtrl.$inject = ['$rootScope', '$scope', '$state', '$stateParams', 'alertService', 'mapping'];
module.exports = indexDetailCtrl;