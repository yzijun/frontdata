var indexCtrl = function($rootScope, $scope, $state, $stateParams, $interval, alertService) {
    var alertList = this;

    alertList.searchName = 'EventTime';
    alertList.sortOrder = 0;

    var currentPage = 1;
    var sizePage = 25;
    // 查询参数
    var paramObj = {
        searchOrder: {
            fieldName: alertList.searchName,
            sortOrder: alertList.sortOrder
        },
        current: currentPage,
        size: sizePage
    }

    // 设置过more filters的过滤条件
    if (angular.isDefined($rootScope.alertSearchFilters)) {
        paramObj.searchFilters = $rootScope.alertSearchFilters.searchFilters;
    }

    // status设置 alert左侧菜单显示项
    function setMenuStatus() {
        alertList.st = $stateParams.status;
        if (alertList.st == 'all') {
            paramObj.status = 0;
        } else if (alertList.st == 'process') {
            paramObj.status = 2;
            // ownerId 用户id
            paramObj.ownerId = $rootScope.auther.data.id;
        } else if (alertList.st == 'unclaimed') {
            paramObj.status = 1;
        } else if (alertList.st == 'myalert') {
            // ownerId 用户id
            paramObj.ownerId = $rootScope.auther.data.id;
        }
    }

    setMenuStatus();

    $scope.maxSize = 5;
    $scope.currentPage = 1;
    $scope.perPage = paramObj.size;
    // 取得分页数据
    $scope.pageChanged = function() {
        paramObj.current = $scope.currentPage;
        alertService.obtainLists(paramObj).then(
            function(response) {
                alertList.lists = response.result.data;
                $scope.totalItems = response.result.total;
            }
        );
    };
    // 取得默认第一页数据
    if ($scope.currentPage == 1) {
        $scope.pageChanged();
    }

    // 手动刷新列表数据
    alertList.refresh = function() {
        paramObj = {
            searchOrder: {
                fieldName: alertList.searchName,
                sortOrder: alertList.sortOrder
            },
            current: currentPage,
            size: sizePage
        }
        setMenuStatus();
        $scope.currentPage = 1;
        $scope.pageChanged();
    }

    // 页面显示排序对象
    alertList.sortOrderObj = {
        EventTime: ['Time', 0],
        Severity: ['Severity', 0],
        AlertName: ['Alert Name', 0]
    }

    // 排序
    alertList.sortList = function(searchName) {

        $(".sortType").html(alertList.sortOrderObj[searchName][0]);
        // 重新设置参数
        alertList.sortOrderObj[searchName][1] = alertList.sortOrderObj[searchName][1] == 0 ? 1 : 0;
        alertList.searchName = searchName;
        alertList.sortOrder = alertList.sortOrderObj[searchName][1];
        paramObj = {
            searchOrder: {
                fieldName: alertList.searchName,
                sortOrder: alertList.sortOrder
            },
            current: currentPage,
            size: sizePage
        }
        setMenuStatus();
        $scope.currentPage = 1;
        $scope.pageChanged();
    }

    // 显示列表或详细
    alertList.detailFlag = true;

    $scope.$on('dismissDetail', function(d, data) {
        alertList.detailFlag = !alertList.detailFlag;
    })

    alertList.id = 0;
    // 列表进入详细页
    alertList.findDetial = function(id) {
        // 点击行设置行变色
        if (alertList.id == 0) {
            alertList.id = id;
        } else {
            $("." + alertList.id).removeClass("setLineBg");
            alertList.id = id;
        }
        $("." + id).addClass("setLineBg");
        alertList.detailFlag = !alertList.detailFlag;
        $state.go('main.alertList.detail', { id: id });
    };
    // 详细列表
    alertList.showDetial = function(id) {
        // 点击行设置行变色
        if (alertList.id == 0) {
            alertList.id = id;
        } else {
            $("." + alertList.id).removeClass("setLineBg");
            alertList.id = id;
        }
        $("." + id).addClass("setLineBg");
        $state.go('main.alertList.detail', { id: id });
    };

    var stop;
    // 自动刷新数据
    function autoRefreshData() {
        // Don't start a new fight if we are already fighting
        if (angular.isDefined(stop)) return;

        stop = $interval(function() {
            $scope.pageChanged();
        }, 5 * 60 * 1000); // 间隔5分钟刷新alert数据
    };

    autoRefreshData();

    function stopRefresh() {
        if (angular.isDefined(stop)) {
            $interval.cancel(stop);
            stop = undefined;
        }
    };

    $scope.$on('$destroy', function() {
        // Make sure that the interval nis destroyed too
        stopRefresh();
    });


};
indexCtrl.$inject = ['$rootScope', '$scope', '$state', '$stateParams', '$interval', 'alertService'];
module.exports = indexCtrl;