var filtersCtrl = function($rootScope, $scope, $state, $stateParams, alertService, alertFilterService) {
    var alertFilters = this;

    function init() {

        // 设置 stauts 下拉列表数据
        alertFilters.status = [{ k: 1, v: 'Unclaimed' }, { k: 2, v: 'In Processed' }, { k: 3, v: 'Closed' }];
        // 设置 operators 下拉列表数据
        alertFilters.operators = [{ k: 0, v: 'is equal to' }, { k: 6, v: 'is not equal to' }, { k: 1, v: 'is greater than' }, { k: 2, v: 'is greater than or equal to' }, { k: 3, v: 'is less than' }, { k: 4, v: 'is less than or equal to' }];
        // 设置 Severity 下拉列表数据
        alertFilters.severities = [1, 2, 3, 4, 5];
        // 设置 Source 下拉列表数据
        alertFilters.sources = ['M&D', 'Smart Signal', 'iHistorian'];
        alertFilters.sourcesOper = [{ k: 0, v: 'is equal to' }, { k: 6, v: 'is not equal to' }];
        // 设置 Event Time下拉列表数据
        alertFilters.eventTimeOper = [{ k: 1, v: 'Last 24 Hours' }, { k: 2, v: 'Last 7 Days' }, { k: 3, v: 'Last 30 Days' }, { k: 4, v: 'Last 3 Months' }, { k: 5, v: 'Last 6 Months' }, { k: 6, v: 'Last 12 Months' }, { k: 7, v: 'Custom Range' }];

        // 取得plant数据
        alertFilterService.getPlants({
            page: {
                searchStr: '',
            },
            siteId: 0
        }).then(
            function(response) {
                // console.log(response.result.data);
                alertFilters.plants = response.result.data;
            }
        );

        // 取得unit数据
        alertFilterService.getUnits({
            page: {
                searchStr: '',
            },
            blockId: 0
        }).then(
            function(response) {
                // console.log(response.result.data);
                alertFilters.units = response.result.data;
            }
        );

        $(".form_datetime").datetimepicker({
            format: "yyyy-mm-dd hh:ii:ss",
            // 设置选择日期 1：小时 2：日期
            minView: 2
        });

        // 没有设置过查询条件
        if (angular.isUndefined($rootScope.alertSearchFilters)) {
            alertFilters.filterStatus = {
                status: false,
                assetName: false,
                ownerAnduserName: false,
                severity: false,
                source: false,
                alertName: false,
                eventTime: false,
                plant: false,
                unit: false
            }

            // 查询条件参数设置
            alertFilters.searchParams = {
                status: { fieldName: 'Status', operator: 0, valueType: 0, intValue: 1 },
                assetName: { fieldName: 'AssetName', operator: 5, valueType: 2, stringValue: '' },
                ownerAnduserName: { fieldName: 'OwnerName', operator: 5, valueType: 2, stringValue: '' },
                severity: { fieldName: 'Severity', operator: 0, valueType: 0, intValue: 1 },
                source: { fieldName: 'AlertSource', operator: 0, valueType: 2, stringValue: 'M&D' },
                alertName: { fieldName: 'AlertName', operator: 5, valueType: 2, stringValue: '' },
                eventTime: { rangeFrom: '', rangeTo: '', eventTimeOper: 1, dateFrom: { fieldName: 'EventTime', operator: 2, valueType: 3, dateTimeValue: '' }, dateTo: { fieldName: 'EventTime', operator: 4, valueType: 3, dateTimeValue: '' } },
                plant: { fieldName: 'PlantName', operator: 0, valueType: 2, stringValue: '' },
                unit: { fieldName: 'UnitName', operator: 0, valueType: 2, stringValue: '' }
            }
        } else {
            alertFilters.filterStatus = $rootScope.alertSearchFilters.filterStatus;
            alertFilters.searchParams = $rootScope.alertSearchFilters.searchParams;
        }

    }

    init();


    // 点击OK
    alertFilters.makeFilters = function() {
        // console.log(JSON.stringify(alertFilters.searchParams));

        // 设置真正的查询参数
        alertFilters.searchFilters = [];

        if (alertFilters.filterStatus.status) {
            alertFilters.searchFilters.push(alertFilters.searchParams.status);
        }
        if (alertFilters.filterStatus.assetName) {
            alertFilters.searchFilters.push(alertFilters.searchParams.assetName);
        }
        if (alertFilters.filterStatus.ownerAnduserName) {
            alertFilters.searchFilters.push(alertFilters.searchParams.ownerAnduserName);
        }
        if (alertFilters.filterStatus.severity) {
            alertFilters.searchFilters.push(alertFilters.searchParams.severity);
        }
        if (alertFilters.filterStatus.source) {
            alertFilters.searchFilters.push(alertFilters.searchParams.source);
        }
        if (alertFilters.filterStatus.alertName) {
            alertFilters.searchFilters.push(alertFilters.searchParams.alertName);
        }
        if (alertFilters.filterStatus.eventTime) {
            // 取得Event Time日期区间标识
            var evoper = alertFilters.searchParams.eventTime.eventTimeOper;
            // Custom Range: 7
            if (evoper == 7) {
                alertFilters.searchParams.eventTime.dateFrom.dateTimeValue = alertFilters.searchParams.eventTime.rangeFrom;
                alertFilters.searchParams.eventTime.dateTo.dateTimeValue = alertFilters.searchParams.eventTime.rangeTo;
            } else {
                var range = alertFilterService.getDateRange(evoper);
                // console.log(range);
                alertFilters.searchParams.eventTime.dateFrom.dateTimeValue = range.startDate;
                alertFilters.searchParams.eventTime.dateTo.dateTimeValue = range.endDate;
            }

            alertFilters.searchFilters.push(alertFilters.searchParams.eventTime.dateFrom);
            alertFilters.searchFilters.push(alertFilters.searchParams.eventTime.dateTo);
        }
        if (alertFilters.filterStatus.plant) {
            alertFilters.searchFilters.push(alertFilters.searchParams.plant);
        }
        if (alertFilters.filterStatus.unit) {
            alertFilters.searchFilters.push(alertFilters.searchParams.unit);
        }

        // console.log(JSON.stringify(alertFilters.searchFilters));

        // 查询条件设置到rootScope,其他alert页面使用
        $rootScope.alertSearchFilters = { searchParams: alertFilters.searchParams, filterStatus: alertFilters.filterStatus, searchFilters: alertFilters.searchFilters };

    }

    // 点击Cancel
    alertFilters.cancelFilters = function() {
        if (angular.isDefined($rootScope.alertSearchFilters)) {
            $rootScope.alertSearchFilters = undefined;
            init();
        }
    }

};
filtersCtrl.$inject = ['$rootScope', '$scope', '$state', '$stateParams', 'alertService', 'alertFilterService'];
module.exports = filtersCtrl;