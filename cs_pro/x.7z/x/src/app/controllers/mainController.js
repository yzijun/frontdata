 
var mainController = function($scope, mainService, $window, notificationManager) {
	require('./../lte.app.js');
	var main = this;

	notificationManager.registerUnreadMessage(function(result) {
		main.unreadMessages = result;
	});
 
	//mainService.obtainAuthByUser("user", "password");
	main.logout=function() {
		notificationManager.terminateToObtainMessage();
		notificationManager.unregisterUnreadMessage();
		$window.location.href="#"
		$window.location.reload();
		
	}

	main.checkAllUnreadMessages = function() {
		console.log("check all");
		var ids = [];
		angular.forEach(main.unreadMessages.data, function(element) {
			ids.push(element.id);
		}, this);
		mainService.markMessagesRead(ids);
	}

	main.showMessageDetail = function(item) {
		main.unreadDetail = item;
	}

	main.markDetail = function(item) {
		var ids = [];
		ids.push(item.id);
		mainService.markMessagesRead(ids);
	}

	notificationManager.beginToObtainMessage();
}
mainController.$inject = ['$scope', 'mainService', '$window', 'notificationManager'];
module.exports = mainController;