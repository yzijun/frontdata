var caseInProcessCtrl = function ($scope, $state,$rootScope, $stateParams,$interval,caseService,caseManager) {
  var caselist = this;
  // caselist.userId = $rootScope.auther.data.id;
  caselist.userId = 1;
  caselist.detailFlag = true;
  caselist.searchName = 'CreationTime';
  caselist.sortOrder = 0;
  var currentPage = 1;
  var sizePage = 25;
  // 查询参数
    var paramObj = {
        searchOrder: {
            fieldName: caselist.searchName,
            sortOrder: caselist.sortOrder
        },
        searchFilters :[],
        current: caselist.currentPage,
        size: sizePage
    }

    caselist.maxSize = 5;
    caselist.currentPage = 1;
    caselist.perPage = paramObj.size;
    
    //获取filter
    paramObj.searchFilters = caseManager.getCurrentFilter();
    console.log(JSON.stringify(paramObj) + "-----------------------列表参数")
    // 取得分页数据
   caselist.pageChanged = function() {
        paramObj.current = caselist.currentPage;
        caseService.obtainCases(paramObj).then(
            function(success) {
                handleRoles(success);
            }
        );
    };

    // 取得默认第一页数据
    if (caselist.currentPage == 1) {
        caselist.pageChanged();
    }

    // status设置左侧菜单显示项
    function setMenuStatus(){
        caselist.st = $stateParams.status;
        if (caselist.st == 'all') {
            paramObj.status = '';
        } else if (caselist.st == 'process') {
            paramObj.status = 2;
        } else if (caselist.st == 'open') {
            paramObj.status = 1;
        } else if (caselist.st == 'close') {
            paramObj.status = 3;
        } else if (caselist.st == 'mycases') {
            // TODO ownerId 用户id
            paramObj.ownerId = caselist.userId;
        }
    }
    setMenuStatus();
    // 页面显示排序对象
    caselist.sortOrderObj = {
        CreationTime: ['CreationTime', 0],
        Severity: ['Severity', 0],
        PlantName: ['PlantName', 0]
    }

    // 排序
    caselist.sortList = function(searchName) {
        $(".sortType").html(caselist.sortOrderObj[searchName][0]);
        // 重新设置参数
        caselist.sortOrderObj[searchName][1] = caselist.sortOrderObj[searchName][1] == 0 ? 1 : 0;
        caselist.searchName = searchName;
        caselist.sortOrder = caselist.sortOrderObj[searchName][1];
        paramObj = {
            searchOrder: {
                fieldName: caselist.searchName,
                sortOrder: caselist.sortOrder
            },
            current: currentPage,
            size: sizePage
        }
        setMenuStatus();
        caselist.currentPage = 1;
        caselist.pageChanged();
    }

     // 手动刷新列表数据
    caselist.refresh = function() {
        paramObj = {
            searchOrder: {
                fieldName: caselist.searchName,
                sortOrder: caselist.sortOrder
            },
            current: currentPage,
            size: sizePage
        }
        setMenuStatus();
        caselist.currentPage = 1;
        caselist.pageChanged();
    }
   //响应事件
   $scope.$on('dismissDetail',function(d,data){
     caselist.detailFlag = !caselist.detailFlag;
   })
   $scope.$on('refreshList',function(d,data) {
     caselist.pageChanged();
   })

   //详情
   caselist.showDetail = function (caseObj) {
     caselist.detailFlag = false;
     caselist.id = caseObj.id;
     $state.go('main.caseList.detail',{"id":caseObj.id});
   };

    //赋值
    function handleRoles(response) {
        caselist.list = response.result.data;
        caselist.totalItems = response.result.total;
    }
    
    //创建case参数
    caselist.serveritys = [1,2,3,4,5];
    caselist.createCaseParams = {
         caseName : "",
         severity :　caselist.serveritys[0],
         status : 0,
         creatorUserId : $rootScope.auther.data.id,
        //  creatorUserId : 1,
         sympotoms : "",
         resource : 0
    }

    //创建log参数
    caselist.createLogParams = {
         creatorUserId:1,
         userName : $rootScope.auther.data.name,
        //  userName : "admin",
         message :　"Create Case",
         type:1
    }

    //创建成功or失败message
    caselist.createCaseFlag = "";
   
    //创建case
    caselist.createCase = function(){
        console.log(JSON.stringify(caselist.createCaseParams)+"========================创建case参数")
        if(caselist.createCaseParams.caseName && caselist.createCaseParams.sympotoms){
            caseService.createCases(caselist.createCaseParams).then(
                function(response) {
                    if(response.result.isCreated){
                        caselist.createCaseFlag = "";
                        caselist.modal = "modal";
                        //重置
                        // caselist.createCaseParams.caseName = "",
                        // caselist.createCaseParams.sympotoms = "",
                        //设置log参数
                        caselist.createLogParams.typeValue = response.result.id;
                        //创建Log
                        caselist.createLog();
                        //刷新列表
                        caselist.pageChanged ();
                    }else{
                        caselist.modal = "";
                        caselist.createCaseFlag = "Create case failed !";
                    }
                }
            );
        }else{
            caselist.createCaseFlag = "Create case failed !";
        }
     
    }
    //创建log
    caselist.createLog = function(){
        caseService.createLog(caselist.createLogParams).then(
             function(response) {}
        );
    }

    var stop;
    // 自动刷新数据
    function autoRefreshData() {
        // Don't start a new fight if we are already fighting
        if (angular.isDefined(stop)) return;

        stop = $interval(function() {
            $scope.pageChanged();
        },  5 * 60 * 1000); // 间隔5分钟刷新case数据
    };

    autoRefreshData();

    function stopRefresh() {
        if (angular.isDefined(stop)) {
            $interval.cancel(stop);
            stop = undefined;
        }
    };

    $scope.$on('$destroy', function() {
        // Make sure that the interval nis destroyed too
        stopRefresh();
    });
};
caseInProcessCtrl.$inject = ['$scope', '$state','$rootScope','$stateParams','$interval','caseService','caseManager'];
module.exports = caseInProcessCtrl;
  
