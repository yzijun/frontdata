var caseDetailCtrl = function ($scope, $state, $stateParams, $rootScope, caseService, mapping) {
    var casedetail = this;
    casedetail.userId = $rootScope.auther.data.id;
    casedetail.userName = $rootScope.auther.data.name;
    // casedetail.userId = 1;
    // casedetail.userName = "admin";
    casedetail.serveritys = mapping.severity;
    casedetail.closeStatus = false;
    //关闭详情
    casedetail.close = function () {
        $scope.$emit('dismissDetail', '');
        $scope.$emit('refreshList', '')
        $state.go('main.caseList.detail');
    };
    //获取log
    casedetail.getLogParams = {
        type: 1,
        typeValue: $stateParams.id
    }
    casedetail.getLogs = function () {
        caseService.obtainLogs(casedetail.getLogParams).then(
            function (response) {
                casedetail.logs = response.result.data;
            }
        );
    }
    casedetail.getLogs();

    //参数
    var paramObj = {
        id: $stateParams.id
    }

    //获取数据
    casedetail.getDetail = function () {
        caseService.obtainCasesDetail(paramObj).then(
            function (response) {
                casedetail.detail = response.result.data;
                console.log(JSON.stringify(casedetail.detail) + "----------------------detail")
                if(casedetail.detail.status == 3){
                    casedetail.closeStatus = true;
                }
                var keyVal = casedetail.detail.closureCode;
                casedetail.closureAction = mapping.closureAction[keyVal];
                casedetail.haveSiteId();
                casedetail.havePlantId();
                casedetail.haveBlockId();
                casedetail.haveUnitId();
            }
        );
    }
    casedetail.getDetail();

    //获取Evidences参数  
    var paramObjEvidences = {
        type: 1, //1 case ; 0 alert
        typeValue: $stateParams.id //当前case id
    }

    //获取Evidences
    casedetail.getEvidences = function () {
        caseService.obtainEvidences(paramObjEvidences).then(
            function (response) {
                console.log("获取Evidences----:" + JSON.stringify(response.result.data));
                casedetail.caseEvidencesList = response.result.data;
            }
        );
    }
    casedetail.getEvidences();

    var getNotesParams = {
        caseId: $stateParams.id
    }
    //获取notes
    casedetail.getAllNotes = function () {
        caseService.obtainNotes(getNotesParams).then(
            function (response) {
                casedetail.noteLists = response.result.data;
            }
        );
    }
    casedetail.getAllNotes();

    //创建Notes参数
    casedetail.createNotesParams = {
        type: 1,
        text: "",
        creatorUserId: casedetail.userId,
        typeValue: $stateParams.id,
        userName: casedetail.userName,
        message: "Create Note",
    }

    //创建notes
    casedetail.createNotes = function () {
        caseService.createNotes(casedetail.createNotesParams).then(
            function (response) {
                if (response.result.isCreated) {
                    casedetail.getAllNotes();
                    casedetail.getLogs();
                }
                console.log("创建note----:" + response.result.isCreated);
            }
        );
    }
    //创建Report
    casedetail.createReport = function () {
        casedetail.detail.message = "Update Report.";
        casedetail.detail.typeValue = $stateParams.id;
        casedetail.detail.userName = casedetail.userName;
        casedetail.detail.type = 1;
        console.log(JSON.stringify(casedetail.detail));
        caseService.updateCase(casedetail.detail).then(
            function (response) {
                if (response.result.isSaved) {
                    casedetail.reportEditFlag = true;
                    casedetail.getLogs();
                }
            }
        );
    }

    //编辑基本信息
    casedetail.editFlag = true;
    casedetail.caseEdit = function () {
         casedetail.editFlag = false;
         casedetail.getDetail();
    }
    casedetail.saveInformation = function () {
        casedetail.detail.userName = casedetail.userName;
        casedetail.detail.creatorUserId = casedetail.userId;
        casedetail.detail.message = "Update Case Information.";
        casedetail.detail.type = 1;
        casedetail.detail.typeValue = $stateParams.id;
        delete  casedetail.detail.plantName;
        delete  casedetail.detail.siteName;
        delete  casedetail.detail.unitName;
        delete  casedetail.detail.blockName;
        delete  casedetail.detail.assetName;
        caseService.updateCase(casedetail.detail).then(
            function (response) {
                if (response.result.isSaved) {
                    casedetail.editFlag = true;
                    casedetail.getLogs();
                    casedetail.getDetail();
                }
            }
        );
    }
    //编辑report
    casedetail.reportEditFlag = true;
    casedetail.caseEditReport = function () {
        casedetail.reportEditFlag = false;
    }
    //点击action
    
    casedetail.changeStatus = function (status) {
      
        casedetail.detail.userName = casedetail.userName;
        casedetail.detail.creatorUserId = casedetail.userId;
        casedetail.detail.message = "Change Case Status To " + status +".";
        casedetail.detail.type = 1;
        casedetail.detail.typeValue = $stateParams.id;
        casedetail.detail.statusName = status;
        casedetail.detail.status = mapping.statusAction[status];
  
        caseService.changeStatus(casedetail.detail).then(
            function (response) {
                if (response.result.isSaved) {
                    if(casedetail.detail.status == 3){
                        casedetail.closeStatus = true;
                    }
                    casedetail.getLogs();
                }
            }
        );
    }
    // 上传文件
    casedetail.upficparam = {
        type: 1,
        typeValue: $stateParams.id,
        creatorUserId: casedetail.userId,
        message:"Upload Evidence.",
        userName : casedetail.userName
    }


    casedetail.setfile = function ($file, param) {
        if ($file && $file.$error == 'pattern') {
            return;
        }
        if ($file) {
            var fileReader = new FileReader();
            fileReader.readAsDataURL($file);
            fileReader.onload = function (e) {
                var base64Data = e.target.result.substr(e.target.result.indexOf('base64,') + 'base64,'.length);
                $scope.$apply(function () {
                    casedetail.upficparam.fileData = base64Data;
                    casedetail.upficparam.name = $file.name;
                    caseService.getFileType(casedetail.upficparam);
                    if(casedetail.upficparam.fileType){
                        casedetail.uploadPic();
                    }else{
                        $('#alertMessage').click();
                    }
                });
            };
        }
    }

    casedetail.uploadPic = function () {
        caseService.upload(casedetail.upficparam).then(
            function (response) {
                if (response.result.isCreated) {
                    casedetail.getEvidences();
                    casedetail.getLogs();
                }
            }
        );
    }
    //文件下载拼接url
    casedetail.url = mapping.urls.fileRootUrl;

    casedetail.closureFlag = true;
    //closureAction
    casedetail.closureActionClick = function (keyVal) {
        casedetail.detail.closureCode = keyVal;
        casedetail.closureFlag = false;
        casedetail.closureAction = mapping.closureAction[keyVal];
    }
    //closure保存
    casedetail.closureSave = function () {
        casedetail.detail.message = "Create Closure Note And Close Case.";
        casedetail.detail.typeValue = $stateParams.id;
        casedetail.detail.userName = casedetail.userName;
        casedetail.detail.type = 1;
        casedetail.detail.status = 3;
        caseService.updateCase(casedetail.detail).then(
            function (response) {
                if (response.result.isSaved) {
                    casedetail.closureFlag = true;
                    casedetail.closeStatus = true;
                    casedetail.getLogs();
                    casedetail.getDetail();
                }
            }
        );
    }

    //是否有siteId
    casedetail.haveSiteId = function () {
        if (casedetail.detail.siteId) {
            casedetail.getPlants(casedetail.detail.siteId,0);
        }
    }
    //是否有plantId
    casedetail.havePlantId = function () {
        if (casedetail.detail.plantId) {
            casedetail.getBlocks(casedetail.detail.plantId,0);
        }
    }
    //是否有blockId
    casedetail.haveBlockId = function () {
        if (casedetail.detail.blockId) {
            casedetail.getUnits(casedetail.detail.blockId,0);
        }
    }
    //是否有unitid
    casedetail.haveUnitId = function () {
        if (casedetail.detail.unitId) {
            casedetail.getAssets(casedetail.detail.unitId,0);
        }
    }
   
    //清空 type:1 site type:2 plant type:3 block type:4 unit
    casedetail.clearDropDown = function(type){
        if( type == 1){
            if (casedetail.blocks) {
                casedetail.blocks.splice(0, casedetail.blocks.length);
            }
            if (casedetail.units) {
                casedetail.units.splice(0, casedetail.units.length);
            }
            if (casedetail.assets) {
                casedetail.assets.splice(0, casedetail.assets.length);
            }
        }else{
            if (casedetail.units) {
                casedetail.units.splice(0, casedetail.units.length);
            }
            if (casedetail.assets) {
                casedetail.assets.splice(0, casedetail.assets.length);
            }
        }
       
    }
    //获取所有site
    casedetail.getSites = function () {
        caseService.obtainSites().then(
            function (response) {
                casedetail.sites = response.result.data;
                console.log(JSON.stringify(response));
            }
        );
    }
    casedetail.getSites();
    //获取plant by site
    casedetail.getPlants = function (keyVal,flag) {
        caseService.obtainPlants(keyVal).then(
            function (response) {
                casedetail.plants = response.result.data;
            }
        );
        if(flag == 1){
            casedetail.clearDropDown(1);
        }
    }

    //获取 block by plant
    casedetail.getBlocks = function (keyVal,flag) {
        if(keyVal){
            caseService.obtainBlocks(keyVal).then(
                function (response) {
                    casedetail.blocks = response.result.data;
                }
            );
        }
        //判断是否执行上一级onchange方法时执行了该方法
        if(flag == 1){
            casedetail.clearDropDown(3);
        }
    }

    //获取Unit by block
    casedetail.getUnits = function (keyVal,flag) {
        if(keyVal){
            caseService.obtainUnits(keyVal).then(
                function (response) {
                    casedetail.units = response.result.data;
                }
            );
        }
        if(flag == 1){
            casedetail.clearDropDown(4);
        }
    }
    //获取asset by units
    casedetail.getAssets = function (keyVal) {
        if(keyVal){
            caseService.obtainAssets(keyVal).then(
                function (response) {
                    casedetail.assets = response.result.data;
                }
            );
        }
    }
    //根据plantId获取执掌
    var masterParams = {
        id: 0
    }
    casedetail.getMasters = function (plantId) {
        masterParams.id = plantId;
        caseService.obtainMasters(masterParams).then(
            function (response) {
                casedetail.masters = response.result.data;
                angular.forEach(casedetail.masters, function (element) {
                    element.select = false;
                }, this);
            }
        );
    }
    //给执掌发送消息
    casedetail.sendMessageParams = {
        "messageDetail": "",
        "recipient": 0,
        "sender": casedetail.userId,
        "status": 0,
        "caseId": $stateParams.id,
        "id": 0
    }
    casedetail.sendMessage = function () {
        angular.forEach(casedetail.masters, function (element) {
            if (element.select) {
                casedetail.sendMessageParams.recipient = element.id
                casedetail.sendMessageHttp();
            }
        }, this);
    }
    casedetail.sendMessageHttp = function () {
        caseService.sendMessage(casedetail.sendMessageParams).then(
            function (response) {
                casedetail.changeStatus("In-process");
                console.log(JSON.stringify(response.result.isCreated) + "------sendMessage");
            }
        );
    }
};
caseDetailCtrl.$inject = ['$scope', '$state', '$stateParams', '$rootScope', 'caseService', 'mapping'];
module.exports = caseDetailCtrl;

