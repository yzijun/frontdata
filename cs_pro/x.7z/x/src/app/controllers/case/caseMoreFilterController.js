var caseFilterController = function($scope, $state, caseService,mapping,caseManager) {
    var casefilter = this;
    casefilter.flag = true;
    casefilter.filter = angular.copy(caseManager.params);
    casefilter.creationTimeOoperator = false;
    //获取case状态
    casefilter.status = mapping.caseStatus;
    //operator
    casefilter.operators = mapping.caseOperator;
    //severity
    casefilter.severitys = mapping.severity;
    //date filter
    casefilter.dates = mapping.caseCreationTimeOperator;
    //filter 
    casefilter.goFilter = function() {
        if(!casefilter.filter.creationTime.selected){
             casefilter.filter.creationTimeTo.selected = false;
        }
        caseManager.work(casefilter.filter);
        console.log(JSON.stringify(caseManager.getCurrentFilter()) +'-------------filterStatus')
    }
    //获取plant
    caseService.obtainAllPlants().then(
        function (response) {
            casefilter.plants = response.result.data;
        }
    );
    //获取所有Unit
    caseService.obtainAllUnits().then(
        function(response) {
            casefilter.units = response.result.data;
        }
    );
    //datefilter
    casefilter.changeDateFilter = function(id){
        casefilter.filter.creationTimeTo.selected = true;
        if(id != 6){
             var range = caseManager.getDateF(id);
             casefilter.creationTimeOoperator = false;
             casefilter.filter.creationTime.dateTimeValue = range.startDate;
             casefilter.filter.creationTimeTo.dateTimeValue = range.endDate;
        }else{
             casefilter.creationTimeOoperator = true;
        }
    }
    $(".form_datetime").datetimepicker({
            format: "yyyy-mm-dd hh:ii:ss",
            // 设置选择日期 1：小时 2：日期
            minView: 2
        });
}
caseFilterController.$inject = ['$scope', '$state', 'caseService','mapping','caseManager'];
module.exports = caseFilterController;