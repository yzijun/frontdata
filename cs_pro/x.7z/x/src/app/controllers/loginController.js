var loginController = function ($scope, $state, mainService, $rootScope) {
	var login = this;

	login.userName = "";
	login.password = "";
	login.localValidation = {
		userName : true,
		password : true
	};
	login.login = function () {
		console.log("login");
		login.localValidation.userName = true;
		login.localValidation.password = true;
		mainService.obtainAuthByUser(login.userName, login.password).then(
			function (response) {
				console.log("login return " + response.result.stateCode + "");
				if (response.result.stateCode == "0") {
					console.log("login success");
					$rootScope.auther = response.result;
					$state.go('main');
				} else {
					console.log("login null need validate");
					login.localValidation.userName = false;
					login.localValidation.password = false;
				}
				
			}, function (error) {
				console.log("login fail");
			}
		);
	}
}
loginController.$inject = ['$scope', '$state', 'mainService', '$rootScope'];
module.exports = loginController;