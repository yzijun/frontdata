var routerConfig = function($stateProvider, $urlRouterProvider, $httpProvider) {
    $stateProvider
        .state('main', {
            url: '/main',
            template: require('./pageviews/main.html'),
            controller: require('./controllers/mainController'),
            controllerAs: 'main'
        })
        .state('main.alertList', {
            url: '/alertList/:status',
            template: require('./pageviews/alert/index.html'),
            controller: require('./controllers/alert/indexController'),
            controllerAs: 'alertList'
        })
        .state('main.alertList.detail', {
            url: '/:id',
            template: require('./pageviews/alert/indexDetail.html'),
            controller: require('./controllers/alert/indexDetailController'),
            controllerAs: 'alertDetail'
        })
        .state('main.alertFilters', {
            url: '/alertFilters',
            template: require('./pageviews/alert/morefilters.html'),
            controller: require('./controllers/alert/moreFiltersController'),
            controllerAs: 'alertFilters'
        })
        .state('main.caseList', {
            url: '/case/inprocess/:status',
            template: require('./pageviews/case/case-inprocess.html'),
            controller: require('./controllers/case/caseInProcessController'),
            controllerAs: 'caselist'
                // ,
                // params: {'data': null}
        })
        .state('main.caseList.detail', {
            url: '/:id',
            template: require('./pageviews/case/case-detail.html'),
            controller: require('./controllers/case/caseDetailController'),
            controllerAs: 'casedetail'
        }).state('main.configuration-role', {
            url: '/configuration/role',
            template: require('./pageviews/configuration/role.html'),
            controller: require('./controllers/configuration/roleController'),
            controllerAs: 'role'
        }).state('main.configuration-role.operations', {
            url: '/:id/oper/:operation',
            template: require('./pageviews/configuration/role-operations.html'),
            controller: require('./controllers/configuration/roleOperationController'),
            controllerAs: 'roleOperation'
        }).state('main.configuration-permission', {
            url: '/configuration/permission',
            template: require('./pageviews/configuration/permission.html'),
            controller: require('./controllers/configuration/permissionController'),
            controllerAs: 'permission'
        }).state('main.configuration-user', {
            url: '/configuration/user',
            template: require('./pageviews/configuration/user.html'),
            controller: require('./controllers/configuration/userController'),
            controllerAs: 'userScope'
        }).state('main.configuration-user.operations', {
            url: '/:id/oper/:operation',
            template: require('./pageviews/configuration/user-operations.html'),
            controller: require('./controllers/configuration/userOperationController'),
            controllerAs: 'userOperation'
        }).state('main.configuration-plantAsset', {
            url: '/configuration/plantAsset',
            template: require('./pageviews/configuration/plantAsset.html'),
            controller: require('./controllers/configuration/plantAssetController'),
            controllerAs: 'plantAsset'
        }).state('main.configuration-plantAsset.tabcontent', {
            url: '/:tab',
            template: function(stateParams) {
                return require('./pageviews/configuration/plantAsset-' + stateParams.tab + '.html');
            },
            controller: require('./controllers/configuration/plantAssetTabcontentController'),
            controllerAs: 'plantAssetTabcontent'
        }).state('main.configuration-plantAsset.tabcontent.operations', {
            //url: '/:params',
            template: function(stateParams) {
                console.log("stateParams.params.tab : " + stateParams.tab + "," + stateParams.operation);
                return require('./pageviews/configuration/plantAsset-' + stateParams.tab + '-operations.html');
            },
            params: {
                "tab": "",
                "operation": "",
                "id": ""
            },
            controller: require('./controllers/configuration/plantAssetTabcontentOperationController'),
            controllerAs: 'plantAssetTabcontentOperation'
        }).state('main.configuration-plantAsset.tabcontent.operations-tag', {
            template: require('./pageviews/configuration/plantAsset-tabTag-operations.html'),
            params: {
                "id": ""
            },
            controller: require('./controllers/configuration/plantAssetTabcontentOperationTagController'),
            controllerAs: 'plantAssetTabcontentOperationTag'
        }).state('main.configuration-message', {
            url: '/configuration/message',
            template: require('./pageviews/configuration/message.html'),
            controller: require('./controllers/configuration/messageController'),
            controllerAs: 'message'
        }).state('main.configuration-message.operations', {
            url: '/:id/oper/:operation',
            template: require('./pageviews/configuration/message-operations.html'),
            controller: require('./controllers/configuration/messageOperationController'),
            controllerAs: 'messageOperation'
        }).state('main.configuration-source', {
            url: '/configuration/source',
            template: require('./pageviews/configuration/source.html'),
            controller: require('./controllers/configuration/sourceController'),
            controllerAs: 'source'
        }).state('login', {
            url: '/login',
            template: require('./pageviews/login.html'),
            controller: require('./controllers/loginController'),
            controllerAs: 'login'
        }).state('main.case-filter', {
            url: '/case/filter',
            template: require('./pageviews/case/case-morefilter.html'),
            controller: require('./controllers/case/caseMoreFilterController'),
            controllerAs: 'casefilter'
        }).state('main.case-all', {
            url: '/case',
            template: require('./pageviews/case/case-all.html'),
            controller: require('./controllers/case/caseInProcessController'),
            controllerAs: 'caselist'
        }).state('main.case-filter.case-all', {
            url: '/case',
            template: require('./pageviews/case/case-all.html'),
            controller: require('./controllers/case/caseInProcessController'),
            controllerAs: 'caselist'
        }).state('main.configuration-kpi', {
            url: '/configuration/kpi',
            template: require('./pageviews/configuration/kpi.html'),
            controller: require('./controllers/configuration/kpiController'),
            controllerAs: 'kpi'
        }).state('main.configuration-kpi.operations', {
            url: '/:id/oper/:operation',
            template: require('./pageviews/configuration/kpi-operations.html'),
            controller: require('./controllers/configuration/kpiOperationController'),
            controllerAs: 'kpiOperation'
        })
    $urlRouterProvider.otherwise("/login");


    $httpProvider.interceptors.push('errorHandlerInterceptor');
    $httpProvider.interceptors.push('authExpiredInterceptor');

};
routerConfig.$inject = ['$stateProvider', '$urlRouterProvider', '$httpProvider'];

module.exports = routerConfig;