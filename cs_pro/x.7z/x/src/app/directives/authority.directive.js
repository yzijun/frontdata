var hasAuthority = function($rootScope) {
    var directive = {
        restrict: 'A',
        link: linkFunc
    };

    return directive;

    function linkFunc(scope, element, attrs) {
        // var authority = attrs.hasAuthority.replace(/\s+/g, '');
        var authority = attrs.hasAuthority.split(",");

        var setVisible = function() {
                element.removeClass('hidden');
            },
            setHidden = function() {
                element.addClass('hidden');
            }

        setHidden();

        var per = $rootScope.auther.data.permission;

        // 一级菜单:1
        if (authority.length == 1) {
            angular.forEach(per, function(element) {
                if (element.name == authority[0]) {
                    // 显示有权限的菜单
                    setVisible();
                }
            });

        }
        // 二级菜单:2
        if (authority.length == 2) {
            angular.forEach(per, function(element) {
                if (element.name == authority[0]) {
                    angular.forEach(element.resources, function(subele) {
                        if (subele.name == authority[1]) {
                            // 显示有权限的菜单
                            setVisible();
                        }
                    });
                }
            });
        }

        // 页面操作:3
        if (authority.length == 3) {
            angular.forEach(per, function(element) {
                if (element.name == authority[0]) {
                    angular.forEach(element.resources, function(subele) {
                        if (subele.name == authority[1]) {
                            angular.forEach(subele.operations, function(operele) {
                                if (operele.name == authority[2]) {
                                    setVisible();
                                }
                            });
                        }
                    });
                }
            });
        }



    }
};

hasAuthority.$inject = ['$rootScope'];

module.exports = hasAuthority;