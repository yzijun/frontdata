var caseHelperServiceScope = function () {
    var mScope = {};
    mScope.params = {
        status : {"fieldName":"Status","operator":0,"valueType":0,"intValue":"", "selected":false},
        assetName :{"fieldName":"AssetName","operator":0,"valueType":2,"stringValue":"", "selected":false},
        ownerName : {"fieldName":"OwnerName","operator":5,"valueType":2,"stringValue":"", "selected":false},
        severity :{"fieldName":"Severity","operator":0,"valueType":0,"intValue":"", "selected":false},
        caseName :{"fieldName":"CaseName","operator":5,"valueType":2,"stringValue":"", "selected":false},
        creationTime :{"fieldName":"CreationTime","operator":2,"valueType":3,"dateTimeValue":"", "selected":false},
        creationTimeTo:{"fieldName":"CreationTime","operator":4,"valueType":3,"dateTimeValue":"", "selected":false},
        plant :{"fieldName":"PlantName","operator":0,"valueType":2,"stringValue":"", "selected":false},
        unit :{"fieldName":"UnitName","operator":0,"valueType":2,"stringValue":"", "selected":false}
    };

    mScope.work = function(input) {
        mScope.params = input;
    }
    
    mScope.getCurrentFilter = function() {
        var paramObj  = [];
        for(item in mScope.params) {
            if (mScope.params[item].selected) {
                paramObj.push(mScope.params[item]);
            }
        }
        return paramObj;
    }

    mScope.getDateF = function(evoper){
        var range = {};
        var curDate = new Date();
        var preDate = new Date();

        switch (evoper) {
            case 0:
                preDate.setDate(preDate.getDate() - 1); //前一天
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 1:
                preDate.setDate(preDate.getDate() - 7); //前7天
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 2:
                preDate.setDate(preDate.getDate() - 30); //前30天
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 3:
                preDate.setMonth(preDate.getMonth() - 3); //前3个月
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 4:
                preDate.setMonth(preDate.getMonth() - 6); //前6个月
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 5:
                preDate.setMonth(preDate.getMonth() - 12); //前12个月
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
        }

        return range;
    }

     //格式化日期,
    function formatDate(date, format) {
        var paddNum = function(num) {
                num += "";
                return num.replace(/^(\d)$/, "0$1");
            }
            //指定格式字符
        var cfg = {
            yyyy: date.getFullYear() //年 : 4位
                ,
            yy: date.getFullYear().toString().substring(2) //年 : 2位
                ,
            M: date.getMonth() + 1 //月 : 如果1位的时候不补0
                ,
            MM: paddNum(date.getMonth() + 1) //月 : 如果1位的时候补0
                ,
            d: date.getDate() //日 : 如果1位的时候不补0
                ,
            dd: paddNum(date.getDate()) //日 : 如果1位的时候补0
                ,
            hh: date.getHours() //时
                ,
            mm: date.getMinutes() //分
                ,
            ss: date.getSeconds() //秒
        }
        format || (format = "yyyy-MM-dd hh:mm:ss");
        return format.replace(/([a-z])(\1)*/ig, function(m) {
            return cfg[m];
        });
    }
    return mScope;
}

caseHelperServiceScope.$inject = [];
module.exports = caseHelperServiceScope;