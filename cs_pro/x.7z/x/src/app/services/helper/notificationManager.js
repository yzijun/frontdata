var notificationServiceScope = function ($interval, mainService) {
    var mScope = {};

    mScope.registerUnreadMessage = function (callback) {
        mScope.unreadCallback = callback
    }

    mScope.unregisterUnreadMessage = function () {
        mScope.unreadCallback = null;
    }

    mScope.beginToObtainMessage = function () {
        mScope.refresh = $interval(function () {
            console.log("repeat");
            var promise = mainService.obtainUnreadMessage();
            if (promise != null) {
                mainService.obtainUnreadMessage().then(
                    function (response) {
                        if (typeof (mScope.unreadCallback) != undefined && mScope.unreadCallback != null) {
                            mScope.unreadCallback(response.result);
                        }
                        //mScope.unread = response.result;
                    }, function (error) {

                    }
                )
            }
        }, 1000, 0);
    }

    mScope.terminateToObtainMessage = function (input) {
        if (typeof (mScope.refresh) != undefined && mScope.refresh != null) {
            $interval.cancel(mScope.refresh);
        }
    }

    return mScope;
}

notificationServiceScope.$inject = ['$interval', 'mainService'];
module.exports = notificationServiceScope;