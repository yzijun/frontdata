var assistantServiceScope = function ($resource, urlParams, $q, mapping) {
	var assistant = {};
	// use for configuration below
	assistant.mResource = $resource(urlParams.template, {}, {
		uploadImg: { method: 'POST' },
		postCreate: { method: 'POST' },
		postUpdate: { method: 'PUT' },
		obtainList: { method: 'POST' },
		obtainListBy: { method: 'POST' },
		obtainBy: { method: 'POST' }
	});

	assistant.uploadImg = function (model, fileName, content) {
		var key = angular.lowercase(fileName.substring(fileName.lastIndexOf(".") + 1));
		var fileType = mapping.fileType[key];
		var defer = $q.defer();
		var postData = {
			"type": model,
			"fileType": fileType,
			"fileData": content
		};
		var api = urlParams.api;
		var method = urlParams.method;
		assistant.mResource.uploadImg(
			{ api: 'file', method: 'UploadImage' }
			, postData
			, function (response) {
				defer.resolve(response);
			}
			, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	
	assistant.postCreateTemplate = function(requestModel, modelMethod, postData) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		assistant.mResource.postCreate(
			{ api: requestModel, method: modelMethod }
			, postData
			, function (response) {
				defer.resolve(response);
			}
			, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	assistant.postUpdateTemplate = function(requestModel, modelMethod, postData) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		assistant.mResource.postUpdate(
			{ api: requestModel, method: modelMethod }
			, postData
			, function (response) {
				defer.resolve(response);
			}
			, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	var pageParams = mapping.pagination;

	assistant.postListTemplate = function(requestModel, modelMethod) {
		var defer = $q.defer();
		var postData = {
			"page": {
				"current": 0,
				"size": mapping.pagination.configurationPerPage
			}
		};
		var api = urlParams.api;
		var method = urlParams.method;
		assistant.mResource.obtainList(
			{ api: requestModel, method: modelMethod }
			, postData
			, function (response) {
				defer.resolve(response);
			}
			, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	assistant.getSites = function () {
		return assistant.postListTemplate('site', 'GetSites');
	}

	assistant.getPlants = function () {
		return assistant.postListTemplate('plant', 'GetPlants');
	}

	assistant.getBlocks = function () {
		return assistant.postListTemplate('block', 'GetBlocks');
	}

	assistant.getAssets = function () {
		return assistant.postListTemplate('asset', 'GetAssets');
	}

	assistant.getUnits = function () {
		return assistant.postListTemplate('unit', 'GetUnits');
	}

	assistant.postSingleListTemplate = function(requestModel, modelMethod, paramData) {
		var defer = $q.defer();
		var postData = {
			"page": {
				"current": 0,
				"size": 10
			}	
		};

		for (var item in paramData) {
			postData[item] = paramData[item];
		}
		//postData[key] = value;
		var api = urlParams.api;
		var method = urlParams.method;
		assistant.mResource.obtainListBy(
			{ api: requestModel, method: modelMethod }
			, postData
			, function (response) {
				defer.resolve(response);
			}
			, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	assistant.getPlantBySite = function (siteId) {
		var paramData = {
			"siteId": siteId
		}
		return assistant.postSingleListTemplate('plant', 'GetPlants', paramData);
	}

	assistant.getBlockByPlant = function (plantId) {
		var paramData = {
			"plantId": plantId
		}
		return assistant.postSingleListTemplate('block', 'GetBlocks', paramData);
	}

	assistant.getUnitByBlock = function (blockId) {
		var paramData = {
			"blockId": blockId
		}
		return assistant.postSingleListTemplate('unit', 'GetUnits', paramData);
	}

	assistant.getAssetByUnit = function (unitId) {
		var paramData = {
			"unitId": unitId
		}
		return assistant.postSingleListTemplate('asset', 'GetAssets', paramData);
	}

	assistant.postSingleTemplate = function(requestModel, modelMethod, id) {
		var defer = $q.defer();
		var postData = {
			"id": id	
		};
		var api = urlParams.api;
		var method = urlParams.method;
		assistant.mResource.obtainListBy(
			{ api: requestModel, method: modelMethod }
			, postData
			, function (response) {
				defer.resolve(response);
			}
			, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	return assistant;
}

assistantServiceScope.$inject = ['$resource', 'urlParams', '$q', 'mapping'];
module.exports = assistantServiceScope;