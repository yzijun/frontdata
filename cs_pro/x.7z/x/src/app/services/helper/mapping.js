var mappingServiceScope = function () {
    var mapping = {};

    mapping.urls = {
        "fileRootUrl": "http://192.168.10.192:8080",
        "template": "http://192.168.10.192:8080/api/services/app/:api/:method",
        "api": "api",
        "method": "method"
    }

    // role
    mapping.roleOperations = {
        "createRole": 0,
        "checkDetail": 1,
        "editRole": 2
    }

    mapping.stateParams = {
        "tabSite": "tabSite",
        "tabPlant": "tabPlant",
        "tabBlock": "tabBlock",
        "tabUnit": "tabUnit",
        "tabAsset": "tabAsset",
        "tabTag": "tabTag"
    }

    mapping.configurationApis = {
        "tabSite": {
            "api": "site"
            , "list": "GetSites"
            , "item": "GetSite"
            , "update": "UpdateSite"
            , "create": "CreateSite"
            , "relation": "siteId"
        },
        "tabPlant": {
            "api": "plant"
            , "list": "GetPlants"
            , "item": "GetPlant"
            , "update": "UpdatePlant"
            , "create": "CreatePlant"
            , "relation": "siteId"
        },
        "tabBlock": {
            "api": "block"
            , "list": "GetBlocks"
            , "item": "GetBlock"
            , "update": "UpdateBlock"
            , "create": "CreateBlock"
            , "relation": "plantId"
        },
        "tabUnit": {
            "api": "unit"
            , "list": "GetUnits"
            , "item": "GetUnit"
            , "update": "UpdateUnit"
            , "create": "CreateUnit"
            , "relation": "blockId"
        },
        "tabAsset": {
            "api": "asset"
            , "list": "GetAssets"
            , "item": "GetAsset"
            , "update": "UpdateAsset"
            , "create": "CreateAsset"
            , "relation": "unitId"
        },

        "tabTag": {
            "api": "tag"
            , "list": "GetTags"
            , "item": "GetTag"
            , "update": "UpdateTag"
            , "create": "CreateTag"
            , "relation": "assetId"
            , "GetTags": { "typeValue": 0, "type": -1 }
        }
    }

    mapping.accuracy = [0, 1, 2, 3, 4];

    mapping.measurement = [{ "name": "Metric", "value": true }, { "name": "Imperial", "value": false }];

    mapping.severity = [1, 2, 3, 4, 5];

    mapping.pagination = {
        "configurationMaxSize" : 9
        ,"configurationPerPage" : 25
        ,"pageAllowed" : true
        ,"pageDisallowed" : false
    }

    mapping.fileType = {
        "bmp": 0,
        "jpg": 1,
        "jpeg": 2,
        "gif": 3,
        "doc": 4,
        "docx": 5,
        "xls": 6,
        "xlsx": 7,
        "ppt": 8,
        "pptx": 9,
        "zip": 10,
        "pdf": 11,
        "png": 12
    }

    mapping.modelType = {
        "Alert": 0,
        "Case": 1,
        "Role": 2,
        "User": 3
    }

    //case closure action
    mapping.closureAction = {
        0: "No Action",
        1: "Sensor Repair",
        2: "Operational Change",
        3: "Scheduled Maintenance",
        4: "Unplanned Maintenance"
    }

    //case action status
    mapping.statusAction = {
        "No Action": 0,
        "Opened": 1,
        "In-process": 2,
        "Closed": 3
    }

    //case filter status
    mapping.caseStatus = [{ name: "Opened", id: 1 }, { name: "In-process", id: 2 }, { name: "Closed", id: 3 }]
    //case filter operator
    mapping.caseOperator = [{ name: "equal", id: 0 }, { name: "more than", id: 1 }, { name: "more than and equal", id: 2 }, { name: "less than", id: 3 }, { name: "less then and equal", id: 4 }]
    //case filter creationTime operator
    mapping.caseCreationTimeOperator = [{ name: "Last 24 Hours", id: 0 }, { name: "Last 7 Days", id: 1 }, { name: "Last 30 Days", id: 2 }, { name: "Last 3 Months", id: 3 }, { name: "Last 6 Months", id: 4 }, { name: "Last 12 Months", id: 5 }, { name: "Custom Range", id: 6 }]
    return mapping;
}

mappingServiceScope.$inject = [];
module.exports = mappingServiceScope;