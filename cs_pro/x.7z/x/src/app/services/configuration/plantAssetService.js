var plantAssetServiceScope = function($resource, urlParams, $q, $rootScope, assistant, mapping) {
	var mService = {}; 

	mService.getPlants = function() {
		return assistant.getPlants();
	}

	mService.getSites = function() {
		return assistant.getSites();
	}

	mService.getPlantBySite = function(siteId) {
		return assistant.getPlantBySite(siteId);
	}

	mService.getBlockByPlant = function(plantId) {
		return assistant.getBlockByPlant(plantId);
	}

	mService.getUnitByBlock = function(blockId) {
		return assistant.getUnitByBlock(blockId);
	}

	mService.getAssetByUnit = function(unitId) {
		return assistant.getAssetByUnit(unitId);
	}

	var configurationApis = mapping.configurationApis;
	mService.obtainModelList = function(model) {
		console.log("configurationApis[model].api " + configurationApis[model].api);
		console.log("configurationApis[model].list " + configurationApis[model].list);
		var listKey = configurationApis[model].list;
		console.log(configurationApis[model][listKey]);
		if (listKey) {
			return assistant.postSingleListTemplate(configurationApis[model].api, configurationApis[model].list, configurationApis[model][listKey]);
		}
		return assistant.postListTemplate(configurationApis[model].api, configurationApis[model].list);
	}

	mService.obtainModelBy = function(model, id) {
		return assistant.postSingleTemplate(configurationApis[model].api, configurationApis[model].item, id);
	}

	// get select list
	mService.getSingleRelationList = function(model, id) {
		var params = {};
		console.log("configurationApis[model].relation " + configurationApis[model].relation);
		params[configurationApis[model].relation] = id;
		return assistant.postSingleListTemplate(configurationApis[model].api, configurationApis[model].list, params);
	}

	// edit
	mService.update = function(model, postData) {
		return assistant.postUpdateTemplate(configurationApis[model].api, configurationApis[model].update, postData);
	}

	mService.create = function(model, postData) {
		return assistant.postCreateTemplate(configurationApis[model].api, configurationApis[model].create, postData);
	}

	return mService;
}

plantAssetServiceScope.$inject = ['$resource', 'urlParams', '$q', '$rootScope', 'assistant', 'mapping'];
module.exports = plantAssetServiceScope;