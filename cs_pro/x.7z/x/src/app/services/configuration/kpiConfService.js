var messageConfServiceScope = function($resource, urlParams, $q, $rootScope) {
	var mService = {}; 

	mService.mResource = $resource(urlParams.template, {}, {
		obtainMasterDatas:{method:'GET'},
		obtainMasterData:{method:'POST'},
		updateMasterData:{method:'PUT'}
	});

	mService.obtainKpiLsit = function() {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainMasterDatas({
			api:'kpi', method:'GetKpiAll'}
			, {}
			, function(response) {
				defer.resolve(response);
			}
			, function(error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	
	mService.obtainMasterData = function(master) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainMasterData({
			api:'masterData', method:'GetMasterData'}
			, {"id" : master}
			, function(response) {
				defer.resolve(response);
			}
			, function(error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.updateMasterData = function(postMasterData) {
		console.log("service update");
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.updateMasterData({
			api:'masterData', method:'UpdateMasterData'}
			, postMasterData
			, function(response) {
				defer.resolve(response);
			}
			, function(error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	return mService;
}

messageConfServiceScope.$inject = ['$resource', 'urlParams', '$q', '$rootScope'];
module.exports = messageConfServiceScope;