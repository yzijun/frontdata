var roleServiceScope = function ($resource, urlParams, $q, $rootScope) {
	var mService = {};

	mService.mResource = $resource(urlParams.template, {}, {
		obtainRoles: { method: 'POST' },
		obtainRoleDetail: { method: 'POST' },
		createRole: { method: 'POST' },
		updateRole: { method: 'POST' }
	});

	mService.obtainRoles = function () {
		var defer = $q.defer();
		var postData = {
			"current": "1",
			"size": "10"
		};
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainRoles(
			{ api: 'role', method: 'GetRoles' }
			, postData
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.obtainRoleDetail = function (id) {
		var defer = $q.defer();
		var postData = {
			"id": id
		};
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainRoleDetail(
			{ api: 'role', method: 'GetRole' }
			, postData
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.createRole = function (postRole) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.createRole(
			{ api: 'role', method: 'CreateRole' }
			, postRole
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.updateRole = function (postRole) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.updateRole(
			{ api: 'role', method: 'UpdateRole' }
			, postRole
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	return mService;
}

roleServiceScope.$inject = ['$resource', 'urlParams', '$q', '$rootScope'];
module.exports = roleServiceScope;