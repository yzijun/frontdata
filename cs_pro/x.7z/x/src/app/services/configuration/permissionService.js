var permissionServiceScope = function($resource, urlParams, $q, $rootScope) {
	var mService = {}; 

	mService.mResource = $resource(urlParams.template, {}, {
		obtainPermissions:{method:'GET'},
		obtainAllRoles:{method:'GET'},
		obtainPermissionByRole:{method:'POST'},
		updateRolePermissions:{method: 'POST'}
	});
	mService.getPermissions = function() {
		var defer = $q.defer();
		var params = {
			
		};
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainPermissions(
			{api:'permission', method:'GetPermissions'}
			, params
			, function(response) {
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.getAllRoles = function() {
		var defer = $q.defer();
		var params = {
			
		};
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainAllRoles(
			{api:'role', method:'GetRolesAll'}
			, params
			, function(response) {
				defer.resolve(response);
			}, function (error) {
				console.log("GetRolesAll error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.getPermissionByRole = function(role) {
		var defer = $q.defer();
		var postData = {
			id : role
		};
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainPermissionByRole(
			{api:'permission', method:'GetRolePermissions'}
			, postData
			, function(response) {
				defer.resolve(response);
			}, function (error) {
				console.log("GetRolePermissions error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.updateRolePermissions = function(role, modules, menus, actions) {
		var defer = $q.defer();
		var postData = {
			"roleId" : role,
			"moduleIdList": modules,
			"resourceIdList": menus,
			"opreationIdList": actions
		};
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainPermissionByRole(
			{api:'permission', method:'SetRolePermissions'}
			, postData
			, function(response) {
				defer.resolve(response);
			}, function (error) {
				console.log("SetRolePermissions error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	return mService;
}

permissionServiceScope.$inject = ['$resource', 'urlParams', '$q', '$rootScope'];
module.exports = permissionServiceScope;