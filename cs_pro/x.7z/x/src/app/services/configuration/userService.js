var userServiceScope = function ($resource, urlParams, $q, $rootScope, assistant, mapping, roleService) {
	var mService = {};

	mService.mResource = $resource(urlParams.template, {}, {
		obtainUsers: { method: 'POST' },
		obtainUser: { method: 'POST' },
		createUser: { method: 'POST' }
	});
	mService.obtainUsers = function () {
		var defer = $q.defer();
		var postData = {
			"current": 0,
			"size": 10
		};
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainUsers(
			{ api: 'user', method: 'GetUsers' }
			, postData
			, function (response) {
				defer.resolve(response);
			}
			, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.obtainUser = function (user) {
		var defer = $q.defer();
		var postData = {
			"id": user
		};
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainUser(
			{ api: 'user', method: 'GetUser' }
			, postData
			, function (response) {
				defer.resolve(response);
			}
			, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.createUser = function (userData) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainUser(
			{ api: 'user', method: 'CreateUser' }
			, userData
			, function (response) {
				defer.resolve(response);
			}
			, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.uploadImg = function ($file, fileContent) {
		return assistant.uploadImg(mapping.modelType.User, $file.name, fileContent);
	}

	mService.obtainRoles = function ($file, fileContent) {
		return roleService.obtainRoles();
	}

	mService.getPlants = function () {
		return assistant.getPlants();
	}

	return mService;
}

userServiceScope.$inject = ['$resource', 'urlParams', '$q', '$rootScope', 'assistant', 'mapping', 'roleService'];
module.exports = userServiceScope;