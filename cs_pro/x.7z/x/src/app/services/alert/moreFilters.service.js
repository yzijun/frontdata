var alerFilterService = function($resource, $q, urlParams) {

    var mService = {};

    mService.mResource = $resource(urlParams.template, {}, {
        getData: { method: 'POST' }
    });

    function getData(urlParam, paramObj) {
        var defer = $q.defer();
        mService.mResource.getData(urlParam, paramObj, function(response) {
            defer.resolve(response);
        }, function(error) {
            defer.reject(error);
        });
        return defer.promise;
    }

    mService.getPlants = function(paramObj) {
        return getData({ api: 'plant', method: 'GetPlants' }, paramObj);
    }

    mService.getUnits = function(paramObj) {
        return getData({ api: 'unit', method: 'GetUnits' }, paramObj);
    }

    //格式化日期,
    function formatDate(date, format) {
        var paddNum = function(num) {
                num += "";
                return num.replace(/^(\d)$/, "0$1");
            }
            //指定格式字符
        var cfg = {
            yyyy: date.getFullYear() //年 : 4位
                ,
            yy: date.getFullYear().toString().substring(2) //年 : 2位
                ,
            M: date.getMonth() + 1 //月 : 如果1位的时候不补0
                ,
            MM: paddNum(date.getMonth() + 1) //月 : 如果1位的时候补0
                ,
            d: date.getDate() //日 : 如果1位的时候不补0
                ,
            dd: paddNum(date.getDate()) //日 : 如果1位的时候补0
                ,
            hh: date.getHours() //时
                ,
            mm: date.getMinutes() //分
                ,
            ss: date.getSeconds() //秒
        }
        format || (format = "yyyy-MM-dd hh:mm:ss");
        return format.replace(/([a-z])(\1)*/ig, function(m) {
            return cfg[m];
        });
    }

    // 取得1-6的时间范围
    mService.getDateRange = function(evoper) {
        // var oldTime = (new Date("2014/03/31 12:10:10")).getTime(); //得到毫秒数 
        // var newTime = new Date(oldTime); //就得到普通的时间了

        var range = {};

        var curDate = new Date();
        var preDate = new Date();

        switch (evoper) {
            case 1:
                preDate.setDate(preDate.getDate() - 1); //前一天
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 2:
                preDate.setDate(preDate.getDate() - 7); //前7天
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 3:
                preDate.setDate(preDate.getDate() - 30); //前30天
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 4:
                preDate.setMonth(preDate.getMonth() - 3); //前3个月
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 5:
                preDate.setMonth(preDate.getMonth() - 6); //前6个月
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
            case 6:
                preDate.setMonth(preDate.getMonth() - 12); //前12个月
                range.startDate = formatDate(preDate);
                range.endDate = formatDate(curDate);
                break;
        }

        return range;
    }

    return mService;

}

alerFilterService.$inject = ['$resource', '$q', 'urlParams'];

module.exports = alerFilterService;