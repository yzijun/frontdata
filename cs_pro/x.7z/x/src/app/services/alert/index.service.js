var alerService = function($resource, $q, urlParams) {

    var mService = {};

    mService.mResource = $resource(urlParams.template, {}, {
        obtainLists: { method: 'POST' }
    });

    function getData(urlParam, paramObj) {
        var defer = $q.defer();
        mService.mResource.obtainLists(urlParam, paramObj, function(response) {
            defer.resolve(response);
        }, function(error) {
            defer.reject(error);
        });
        return defer.promise;
    }

    mService.obtainLists = function(paramObj) {
        return getData({ api: 'alert', method: 'GetAlerts' }, paramObj);
    }

    mService.getAlertById = function(paramObj) {
        return getData({ api: 'alert', method: 'GetAlert' }, paramObj);
    }

    mService.detailUploadPic = function(paramObj) {
        return getData({ api: 'alert', method: 'CreateAlertEvidence' }, paramObj);
    }

    mService.getNotes = function(paramObj) {
        return getData({ api: 'note', method: 'GetNotes' }, paramObj);
    }

    mService.createNote = function(paramObj) {
        return getData({ api: 'alert', method: 'CreateAlertNote' }, paramObj);
    }

    mService.getEvidences = function(paramObj) {
        return getData({ api: 'evidence', method: 'GetEvidences' }, paramObj);
    }

    mService.updateAlertStatus = function(paramObj) {
        return getData({ api: 'alert', method: 'SetAlertStatus' }, paramObj);
    }

    mService.createCase = function(paramObj) {
        return getData({ api: 'alert', method: 'CreateAlertCase' }, paramObj);
    }

    mService.getLogs = function(paramObj) {
        return getData({ api: 'log', method: 'GetLogsBy' }, paramObj);
    }

    // 取得文件后缀名匹配api的fileType枚举
    mService.getFileType = function(param) {
        var fileArr = param.name.split(".");
        var fileSuffix = angular.lowercase(fileArr[fileArr.length - 1]);
        switch (fileSuffix) {
            case 'bmp':
                param.fileType = 0;
                break;
            case 'jpg':
                param.fileType = 1;
                break;
            case 'jpeg':
                param.fileType = 2;
                break;
            case 'gif':
                param.fileType = 3;
                break;
            case 'png':
                param.fileType = 12;
                break;
        }
        return param;
    }


    return mService;

}

alerService.$inject = ['$resource', '$q', 'urlParams'];

module.exports = alerService;