var caseServiceScope = function ($resource, urlParams, $q, $rootScope,mapping,assistant) {
	var mService = {};

	mService.mResource = $resource(urlParams.template, {}, {
		obtainCase: { method: 'POST' },
		updateCase : {method : 'PUT'}
	});

	//获取case列表
	mService.obtainCases = function (paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'case', method: 'GetCases' }
			, paramObj
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	//获取case详情
	mService.obtainCasesDetail = function (paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'case', method: 'GetCase' }
			, paramObj
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	//创建case
	mService.createCases = function (paramObj) {

		console.log(JSON.stringify(paramObj)+"-----------createCase");
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'case', method: 'CreateCase' }
			, paramObj
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取Evidences
	mService.obtainEvidences = function(paramObj){
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'evidence', method: 'GetEvidences' }
			, paramObj
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取notes
	mService.obtainNotes = function(paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'note', method: 'GetNotes' }
			, paramObj
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//创建note
	mService.createNotes = function(paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'case', method: 'CreateCaseNote' }
			, paramObj
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//保存Report
	mService.updateCase = function(paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.updateCase(
			{ api: 'case', method: 'UpdateCase' }
			, paramObj
			, function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	// 取得文件后缀名匹配api的fileType枚举
    mService.getFileType = function(param) {
        var fileArr = param.name.split(".");
        var fileSuffix = angular.lowercase(fileArr[fileArr.length - 1]);
		param.fileType = mapping.fileType[fileSuffix];
        return param;
    }
       
	mService.upload = function(paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'case', method: 'CreateCaseEvidence'}
			, paramObj
			, function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取所有plant
	mService.obtainAllPlants = function() {
		var defer = $q.defer();
		assistant.getPlants().then(
			function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取所有unit
	mService.obtainAllUnits = function() {
		var defer = $q.defer();
		assistant.getUnits().then(
			function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取asset by unit
	mService.obtainAssets = function(paramObj) {
		var defer = $q.defer();
		assistant.getAssetByUnit(paramObj).then(
			function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取units by block
	mService.obtainUnits = function(paramObj) {
		var defer = $q.defer();
		assistant.getUnitByBlock(paramObj).then(
			function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取block by plant
	mService.obtainBlocks = function(paramObj) {
		var defer = $q.defer();
		assistant.getBlockByPlant(paramObj).then(
			function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取plant by site
	mService.obtainPlants = function(paramObj) {
		var defer = $q.defer();
		assistant.getPlantBySite(paramObj).then(
			function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取所有site
	mService.obtainSites = function() {
		var defer = $q.defer();
		assistant.getSites().then(
			function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	//创建log
	mService.createLog = function(paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'log', method: 'CreateLog' }
			, paramObj
			, function (response) {
				console.log("request sucess");
				defer.resolve(response);
			}, function (error) {
				console.log("request error");
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//获取logs
	mService.obtainLogs = function(paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'log', method: 'GetLogsBy' }
			, paramObj
			, function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//改变case status
	mService.changeStatus = function(paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'case', method: 'SetCaseStatus' }
			, paramObj
			, function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//根据plantid 获取执掌
	mService.obtainMasters = function(paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'user', method: 'GetNotifyUserByPlant' }
			, paramObj
			, function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	//发送消息
	mService.sendMessage = function(paramObj) {
		var defer = $q.defer();
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.obtainCase(
			{ api: 'message', method: 'CreateMessage' }
			, paramObj
			, function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}
	return mService;
}

caseServiceScope.$inject = ['$resource', 'urlParams', '$q', '$rootScope','mapping','assistant'];
module.exports = caseServiceScope;