var mainServiceScope = function ($resource, urlParams, $q, assistant, $rootScope) {
	var mService = {};

	mService.mResource = $resource(urlParams.template, {}, {
		login: { method: 'POST' }
	});
	mService.obtainAuthByUser = function (name, pwd) {
		var defer = $q.defer();
		var postData = {
			"userName": name,
			"password": pwd
		};
		var api = urlParams.api;
		var method = urlParams.method;
		mService.mResource.login({ api: 'user', method: 'Login' }
			, postData
			, function (response) {
				defer.resolve(response);
			}, function (error) {
				defer.reject(error);
			}
		);
		return defer.promise;
	}

	mService.obtainUnreadMessage = function () {
		if (typeof($rootScope.auther) == undefined || $rootScope.auther == null) {
			return null;
		}
		return assistant.postSingleTemplate("message", "GetUnreadMessages", $rootScope.auther.data.id);
	}

	mService.markMessagesRead = function (ids) {
		angular.forEach(ids, function (element) {
			var postData = {
				"id": element,
				"status": true
			}
			assistant.postUpdateTemplate("message", "UpdateStatus", postData);
		}, this);
	}

	return mService;
}

mainServiceScope.$inject = ['$resource', 'urlParams', '$q', 'assistant', '$rootScope'];
module.exports = mainServiceScope;