var authExpService = function($rootScope, $q, $injector) {
    return {
        responseError: function(response) {
            // angular.isUndefined($rootScope.auther)
            if (response.result == 401) {
                var $state = $injector.get('$state');
                $state.go('login');
            }
            return $q.reject(response);
        }
    };
}

authExpService.$inject = ['$rootScope', '$q', '$injector'];

module.exports = authExpService;