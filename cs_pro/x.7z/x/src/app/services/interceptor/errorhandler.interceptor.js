var errorService = function($rootScope, $q) {
    return {
        'responseError': function(response) {
            if (!(response.result == 401)) {
                $rootScope.$emit('cmApp.httpError', response);
            }
            return $q.reject(response);
        }
    };
}

errorService.$inject = ['$rootScope', '$q'];

module.exports = errorService;