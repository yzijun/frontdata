var runHandle = function($rootScope, $window, $location, $state) {
    var stateChangeStart = $rootScope.$on('$stateChangeStart', function(event, toState, toStateParams, fromState) {
        $rootScope.toState = toState;
        $rootScope.toStateParams = toStateParams;
        $rootScope.fromState = fromState;

        // if ($rootScope.auther == undefined) {
        //     $state.go('login');
        // }


    });

};
runHandle.$inject = ['$rootScope', '$window', '$location', '$state'];

module.exports = runHandle;