require('bootstrap-webpack!../../bootstrap.config.js'); //bootstrap
require('./styles/css/font-awesome.css'); //font-awesome
require('./styles/css/ionicons.css'); //ionicons
require('./styles/css/AdminLTE.css'); //AdminLTE
require('./styles/css/all-skins.css'); //AdminLTE
require('./styles/css/iconfont.css'); //font css
require('./styles/css/bootstrap-datetimepicker.css'); //bootstrap-datetimepicker
require('./angular-loading-bar/loading-bar.css'); //angular-loading-bar

var $ = require('jquery'); //jquery

// 页面加载图片示例
// $("img").attr("src",require('./styles/img/user2-160x160.jpg'));

require('./bootstrap-datetime-picker/bootstrap-datetimepicker.js'); //bootstrap-datetimepicker


require('./app.module'); //module