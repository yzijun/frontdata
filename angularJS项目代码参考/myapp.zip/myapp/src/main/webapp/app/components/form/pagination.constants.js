(function() {
    'use strict';

    angular
        .module('myappApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
