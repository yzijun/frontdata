package com.mycompany.myapp.domain.enumeration;

/**
 * The Language enumeration.
 */
public enum Language {
    FRENCH,ENGLISH,SPANISH
}
